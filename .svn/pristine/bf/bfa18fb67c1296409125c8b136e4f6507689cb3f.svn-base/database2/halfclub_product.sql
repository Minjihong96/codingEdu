-- 상품 재고 테이블
CREATE TABLE PRODUCT (
    PRODUCT_ID      NUMBER PRIMARY KEY,          -- 상품 고유 ID
    PRODUCT_NAME    VARCHAR2(200) NOT NULL,      -- 상품 이름
    BRAND           VARCHAR2(100),               -- 브랜드 이름
    COLOR           VARCHAR2(50),                -- 색상
    PRODUCT_SIZE    VARCHAR2(20),                -- 사이즈
    STOCK_QTY       NUMBER DEFAULT 0,            -- 재고 수량
    PRICE 			NUMBER DEFAULT 0             -- 가격
);
INSERT INTO PRODUCT VALUES(1001,'반팔 캐주얼셔츠', '닥스셔츠','white','M(95)', 15, 69000);
INSERT INTO PRODUCT VALUES(1002,'반팔 캐주얼셔츠', '닥스셔츠','white','L(100)', 20, 69000);
INSERT INTO PRODUCT VALUES(1003,'반팔 캐주얼셔츠', '닥스셔츠','white','S(90)', 13, 69000);
INSERT INTO PRODUCT VALUES(1004,'반팔 캐주얼셔츠', '닥스셔츠','black','S(90)', 8, 69000);
INSERT INTO PRODUCT VALUES(1005,'반팔 캐주얼셔츠', '닥스셔츠','black','M(95)', 0, 69000);
INSERT INTO PRODUCT VALUES(1006,'반팔 캐주얼셔츠', '닥스셔츠','black','L(100)', 12, 69000);
INSERT INTO PRODUCT VALUES(1007,'쿨 컴포트 린넨 반팔 셔츠', '올젠셔츠','white','M(95)', 9, 33150);
INSERT INTO PRODUCT VALUES(1008,'쿨 컴포트 린넨 반팔 셔츠', '올젠셔츠','white','L(100)', 0, 33150);
INSERT INTO PRODUCT VALUES(1009,'쿨 컴포트 린넨 반팔 셔츠', '올젠셔츠','white','S(90)', 8, 33150);
INSERT INTO PRODUCT VALUES(1010,'쿨 컴포트 린넨 반팔 셔츠', '올젠셔츠','black','S(90)', 10, 33150);
INSERT INTO PRODUCT VALUES(1011,'쿨 컴포트 린넨 반팔 셔츠', '올젠셔츠','black','M(95)', 12, 33150);
INSERT INTO PRODUCT VALUES(1012,'쿨 컴포트 린넨 반팔 셔츠', '올젠셔츠','black','L(100)', 15, 33150);
INSERT INTO PRODUCT VALUES(1013,'쿨 컴포트 린넨 반팔 셔츠', '올젠셔츠','navy','S(90)', 11, 33150);
INSERT INTO PRODUCT VALUES(1014,'쿨 컴포트 린넨 반팔 셔츠', '올젠셔츠','navy','M(95)', 0, 33150);
INSERT INTO PRODUCT VALUES(1015,'쿨 컴포트 린넨 반팔 셔츠', '올젠셔츠','navy','L(100)', 5, 33150);
INSERT INTO PRODUCT VALUES(1016,'남성 블루 버튼다운 면 반팔 캐주얼 셔츠', '헤지스','blue','S(90)', 3, 69900);
INSERT INTO PRODUCT VALUES(1017,'남성 블루 버튼다운 면 반팔 캐주얼 셔츠', '헤지스','blue','M(95)', 7, 69900);
INSERT INTO PRODUCT VALUES(1018,'남성 블루 버튼다운 면 반팔 캐주얼 셔츠', '헤지스','blue','L(100)', 2, 69900);
INSERT INTO PRODUCT VALUES(1019,'지금부터 여름까지 셔츠', '헤리슨','white','S(90)', 13, 16920);
INSERT INTO PRODUCT VALUES(1020,'지금부터 여름까지 셔츠', '헤리슨','white','M(95)', 6, 16920);
INSERT INTO PRODUCT VALUES(1021,'지금부터 여름까지 셔츠', '헤리슨','white','L(100)', 15, 16920);
INSERT INTO PRODUCT VALUES(1022,'지금부터 여름까지 셔츠', '헤리슨','black','S(90)', 10, 16920);
INSERT INTO PRODUCT VALUES(1023,'지금부터 여름까지 셔츠', '헤리슨','black','M(95)', 9, 16920);
INSERT INTO PRODUCT VALUES(1024,'지금부터 여름까지 셔츠', '헤리슨','black','L(100)', 5, 16920);
INSERT INTO PRODUCT VALUES(1025,'지금부터 여름까지 셔츠', '헤리슨','gray','S(90)', 8, 16920);
INSERT INTO PRODUCT VALUES(1026,'지금부터 여름까지 셔츠', '헤리슨','gray','M(95)', 5, 16920);
INSERT INTO PRODUCT VALUES(1027,'지금부터 여름까지 셔츠', '헤리슨','gray','L(100)', 3, 16920);
INSERT INTO PRODUCT VALUES(1028,'사계절 인기 긴소매 셔츠', '예작','white','S(90)', 8, 22530);
INSERT INTO PRODUCT VALUES(1029,'사계절 인기 긴소매 셔츠', '예작','white','M(95)', 0, 22530);
INSERT INTO PRODUCT VALUES(1030,'사계절 인기 긴소매 셔츠', '예작','white','L(100)', 5, 22530);
INSERT INTO PRODUCT VALUES(1031,'사계절 인기 긴소매 셔츠', '예작','black','S(90)', 4, 22530);
INSERT INTO PRODUCT VALUES(1032,'사계절 인기 긴소매 셔츠', '예작','black','M(95)', 3, 22530);
INSERT INTO PRODUCT VALUES(1033,'사계절 인기 긴소매 셔츠', '예작','black','L(100)', 0, 22530);
UPDATE PRODUCT
	SET STOCK_QTY = 10
WHERE PRODUCT_ID=1001;

SELECT * FROM PRODUCT;
SELECT PRODUCT_SIZE, COLOR, STOCK_QTY FROM PRODUCT WHERE PRODUCT_NAME='반팔 캐주얼셔츠';
DROP TABLE PRODUCT;

SELECT SUM(STOCK_QTY) TOTAL_STOCK FROM PRODUCT;

/*
TABLE PRODUCT (
   PRODUCT_ID      NUMBER PRIMARY KEY,
   PRODUCT_NAME   VARCHAR2(200) NOT NULL,
   BRAND         VARCHAR2(100),
   IMAGE         VARCHAR2(100)
)

TABLE PRODUCT_DETAIL (
   PRODUCT_ID      NUMBER FK,
   PRO_DE_ID      NUMBER PRIMARY KEY,
   COLOR         VARCHAR2(50),
   SIZE         VARCHAR2(50),
   QTY            NUMBER DEFAULT 0,
   PRICE         NUMBER DEFAULT 0
)

for(product p:dao.getXXX(sch)){
   if(!p.qty*p.prid == 0){
      <div src="${p.image}">
         <div>
         for(product_detail pd:dao.getxxx(sch)){         
            <h2>${pd.color} {pd.size}{pd.qty}
            }
         </div>
      </div>
      <h2>${p.name}   
   }

public class Product{
   productId;
   productName;
   brand;
   image;
   color
   size
   qty
   price
   
   public int totprice(){
      return qty * price;
   }
   

*/