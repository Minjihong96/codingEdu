/*
# ORACLE 테이블 구조 변경
1. oracle에서 테이블 구조를 변경하는 데는 ALTER TABLE 명령어를 사용합니다.
테이블 구조 변경은 컬럼 추가, 삭제, 수정과 같은 작업을 포함할 수 있습니다. 이러한 변경을 통해
테이블의 스키마를 수정하거나 데이터를 효율적으로 저장할 수 있는 방식으로 구조를 변경할 수 있습니다.
2. 주요 ALTER TABLE 명령어
	1) 컬럼 추가(ADD)
		새로운 컬럼을 테이블에 추가할 수 있습니다.
		ALTER TABLE 테이블명
		ADD( 컬럼명 데이터 유형 );
	2) 컬럼 삭제(DROP)
		기본 컬럼을 테이블에서 삭제할 수 있습니다.
		ALTER TABLE 테이블명
		DROP COLUMN 삭제할 컬럼
	3) 컬럼 수정(MODIFY)
		컬럼의 데이터 타입이나 제약 조건을 변경할 수 있습니다.
		ALTER TABLE 테이블명
		MODIFY(컬럼명 데이터유형)
	4) 테이블 이름 변경(RENAME)
		테이블의 이름을 변경할 수 있습니다.
		ALTER TABLE 테이블명
		RENAME TO 테이블명
	5) 컬럼 이름 변경(RENAME COLUMN)
		기존 컬럼의 이름을 변경할 수 있습니다.
		ALTER TABLE 테이블명
		RENAME COLUMN 기존컬럼명 TO 새로운 컬럼명
	6) 컬럼의 제약 조건 추가/삭제(ADD/DROP CONSTRAINT)
		기존 테이블에 제약 조건을 추가하거나 삭제 할 수 있습니다.
		- 제약 조건 추가
		ALTER TABLE 테이블명
		ADD CONSTRAINT 제약조건명 제약조건유형(컬럼명)
		- 제약 조건 삭제
		ALTER TABLE 테이블명
		DROP CONSTRAINT 제약조건명
*/
SELECT * FROM EMP08;
-- 주소 컬럼을 추가
ALTER TABLE EMP08
ADD ADDRESS VARCHAR2(500);
SELECT * FROM EMP08;
SELECT * FROM EMP07;
-- EX) EMP07 테이블에 EMAIL을 추가하세요 DEFAULT 'xxxx.gmail.com'설정
ALTER TABLE EMP07
ADD EMAIL VARCHAR2(500) DEFAULT 'xxxx.gmail.com';
-- 컬럼 삭제
SELECT * FROM EMP04;
ALTER TABLE EMP04
DROP COLUMN DEPTNO;
-- 테이블 삭제 DROP TABLE 테이블명;
SELECT * FROM EMP02;
-- EX) 사원번호 사원명 직책을 제외한 모든 컬럼삭제처리
ALTER TABLE EMP02
DROP COLUMN DEPTNO;
-- ORACLE에서는 컬럼 DROP COLUMN사용시 한번에 하나씩 삭제가능 (다중x)

SELECT * FROM EMP03;
-- 테이블의 컬럼 구조 변경
ALTER TABLE EMP03 
MODIFY(NAME VARCHAR2(50));
-- 구조 변경은 데이터 있을 때는 등록된 데이터의 크기 이상으로는 변경가능, 작게 변경불가
-- 			데이터가 같은 유형에 맞게 변경 가능
--			데이터가 없을 때는 데이터 크기나 유형이 다르더라도 변경이 가능하다.

