SELECT * FROM EMP10;
UPDATE EMP10
	SET EMPNO = EMPNO-6000;
--SQL 작성
CREATE SEQUENCE EMP10_SEQ
	START WITH 2000;
ALTER TABLE EMP10
MODIFY( ENAME VARCHAR2(50), JOB VARCHAR2(50)); -- 구조 변경

INSERT INTO EMP10 VALUES(EMP10_SEQ.NEXTVAL, '홍길동', '사원', 7698, TO_DATE('2025-05-26','YYYY-MM-DD'), 3000,100,10);
-- 입력 유형과 이에 맞는 DTO 생성
/* 입력값이 type과 컬럼명에 매칭되는 객체를 생성
class Emp10{
	private String ename;
	private String job;
	private int mgr;
	private String hiredateStr;
	private double sal;
	private double comm;
	private int deptno;
}

public int insertEmp10(Emp10 ins){
	int insCnt = 0;
	String sql = "INSERT INTO EMP10 VALUES(EMP10_SEQ.NEXTVAL, ?, ?, ?, TO_DATE(?,'YYYY-MM-DD'), ?, ?, ?)";
	

	return insCnt;
}
*/

SELECT * FROM FAMILY; -- FAMILY_SEQ 
CREATE SEQUENCE FAMILY_SEQ 
	START WITH 7;
/*
class Family{
	private String name;
	private int parentId;
}

public int insertFamily(Family ins){
	int insCnt = 0;
	String sql = "INSERT INTO FAMILY VALUES(FAMILY_SEQ.NEXTVAL, ?, ?";
	
	return insCnt;
}
*/

SELECT * FROM DEPT01;
-- 1. SQL 작성
UPDATE DEPT01 
	SET DNAME = '인사',
		LOC = '성남'
	WHERE DEPTNO = 30;
-- 2. VO/DTO
-- 3. 메서드
/*
public int updateDept01(Dept upt){
	int uptCnt = 0;
	String sql = "UPDATE DEPT01 SET DNAME = ?, LOC = ? WHERE DEPTNO = ? ";
	
	return uptCnt;
} 
*/

SELECT * FROM DEPT01;
DELETE FROM DEPT01 WHERE DEPTNO = 81;
/*
public int deleteDept01(int deptno){
	int delCnt = 0;
	String sql= "DELETE FROM DEPT01 WHERE DEPTNO = ?";
	
	return delCnt;
}
*/
SELECT * FROM EMP01;
DELETE FROM EMP01 WHERE EMPNO = 1003;

SELECT * FROM FAMILY 
WHERE NAME LIKE '%%';
/*
SELECT S.*, P.NAME PNAME 
FROM FAMILY S, FAMILY P
WHERE S.PARENT_ID = P.PERSON_ID
AND S.NAME LIKE ?
AND P.NAME LIKE ?
*/
-- 계층 구조에 대한 내용을 처리하 때, 처리되는 부분

