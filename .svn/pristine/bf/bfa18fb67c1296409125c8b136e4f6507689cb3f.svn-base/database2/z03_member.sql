/*
# login DAO/jsp 로그인 화면 처리
1. sql 작성
*/
CREATE TABLE MEMBER(
	ID VARCHAR2(50) PRIMARY KEY,
	PWD VARCHAR2(20),
	NAME VARCHAR2(50),
	AUTH VARCHAR2(50),
	POINT NUMBER(5,0)
);
INSERT INTO MEMBER VALUES('himan','7777','홍길동','관리자',1000);
INSERT INTO MEMBER VALUES('higirl','8888','홍마리','일반사용자',2000);
INSERT INTO MEMBER VALUES('goodman','9999','김철수','방문자',3000);
SELECT * FROM MEMBER WHERE ID = 'himan' AND PWD = '7777';
/*
2. 입력 : ID(문자열), PWD(문자열) ==> String id, String pwd
   출력 : ID, PWD, NAME, AUTH, POINT ==> String id, String pwd, String name, String auth, int point
class Member{
	private String id;
	private String pwd;
	private String name;
	private String auth;
	private int point;
}
3. 기능 메서드 선언
public Member login(Member mem){
	Member dto = null;
	String sql = "SELECT * FROM MEMBER WHERE ID = ? AND PWD = ?";
	
	return dto;
}

4. 화면단 구현
*/

SELECT * FROM MEMBER;
CREATE TABLE MEMBER01(
	ID VARCHAR2(50) PRIMARY KEY,
	PWD VARCHAR2(20),
	NAME VARCHAR2(50),
	AUTH VARCHAR2(50),
	REMEMBER_ME CHAR(1) DEFAULT 'N' CHECK (REMEMBER_ME IN ('Y', 'N'))
);
DROP TABLE MEMBER01;
INSERT INTO MEMBER01 VALUES('qwer123@naver.com','7777', '이기찬', '관리자', 'N');
INSERT INTO MEMBER01 VALUES('qwer1234@naver.com','7777', '김하나', '일반사용자', 'N');
INSERT INTO MEMBER01 VALUES('qwer1235@naver.com','7777','안유리', '방문자', 'N');
INSERT INTO MEMBER01 VALUES('qwer1236@naver.com','7777', '공정배', '관리자', 'N');
SELECT * FROM MEMBER01;

/*
class MemberDto{
	private String emailAddress;
	private String pwd;
	private String rememberMe;
}

class MemberDao2{} 

1. 기본 form 화면 만들기 (요청값 처리가 가능 하도록)
2. dao 처리
	1) sql
	2) 입력값/ 출력
	3) Dto : MemberDto
	4) 메서드 정의
public MemberDto login(MemberDto mem){
	MemberDto dto = null;
	String sql = "SELECT * FROM MEMBER01 WHERE ID = ? AND PWD = ?";
	
	return dto;
}
	5) try catch 복사
	6) mapping 처리/resultset
3. jsp : useBean 설정 처리
*/

CREATE TABLE FavoriteMovies (
    movie_id NUMBER PRIMARY KEY,       -- 영화 ID
    movie_title VARCHAR2(100),         -- 영화 제목
    movie_genre VARCHAR2(50),          -- 장르
    fan_name VARCHAR2(50),             -- 팬 이름
    fan_hobby VARCHAR2(100),           -- 팬 취미
    movie_rating NUMBER               -- 영화 평점 (1~10)
);
-- 영화 데이터 삽입
INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (1, '기생충', '드라마', '김영희', '영화 감상, 독서', 9);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (2, '어벤져스: 엔드게임', '액션', '이철수', '게임, 운동', 10);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (3, '겨울왕국', '애니메이션', '박지민', '그림 그리기, 춤', 8);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (4, '기억의 밤', '스릴러', '최준호', '축구, 독서', 7);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (5, '어바웃 타임', '로맨스', '홍길동', '여행, 사진 찍기', 8);

-- 추가된 10건의 영화 데이터 삽입
INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (6, '스파이더맨: 노 웨이 홈', '액션', '정서영', '게임, 만화책 읽기', 9);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (7, '어벤져스: 인피니티 워', '액션', '이승민', '운동, 영화 감상', 8);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (8, '그랜드 부다페스트 호텔', '코미디', '최윤희', '여행, 미술', 8);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (9, '다크 나이트', '액션', '박상민', '책 읽기, 운동', 10);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (10, '인셉션', 'SF', '오준호', '사진 찍기, 영화 감상', 9);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (11, '소울', '애니메이션', '이수연', '음악, 춤', 9);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (12, '스타 워즈: 깨어난 포스', 'SF', '김민수', '운동, 별 보기', 8);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (13, '타이타닉', '로맨스', '황보미', '여행, 요리', 9);

INSERT INTO FavoriteMovies (movie_id, movie_title, movie_genre, fan_name, fan_hobby, movie_rating)
VALUES (14, '겨울왕국 2', '애니메이션', '조아라', '그림 그리기, 춤', 8);

SELECT * FROM FavoriteMovies;

SELECT * FROM FavoriteMovies WHERE MOVIE_TITLE LIKE '%%' AND MOVIE_GENRE LIKE '%%';

/*
1. sql : String sql = "SELECT * FROM FavoriteMovies WHERE MOVIE_TITLE LIKE ? AND MOVIE_GENRE LIKE ?";
2. 입력값 : String movieTitle, String movieGenre
   출력값 : int movieId, String movieTitle, String movieGenre, String fanName, String fanHobby, int movieRating
   
public List<FavoriteMovies> getFavoriteMoviesSch(FavoriteMovies sch){
	List<FavoriteMovies> list  = new ArrayList<FavoriteMovies>();
	String sql = "SELECT * FROM FavoriteMovies WHERE MOVIE_TITLE LIKE ? AND MOVIE_GENRE LIKE ?";
	
	return list;
}
*/