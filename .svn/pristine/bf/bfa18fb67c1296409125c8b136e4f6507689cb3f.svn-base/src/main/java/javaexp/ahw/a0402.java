package javaexp.ahw;

import java.util.Scanner;

public class a0402 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 1. **🍜 라면 끓이기 순서 시뮬레이션 (자바)**  
   			- 라면을 끓이기 위해 순차적으로 `물 끓이기 → 면 넣기 → 스프 넣기 → 3분 대기 → 완성`이라는 단계를 `System.out.println()`으로 출력해보세요.
		 */
		String nuddle[] = {"물 끓이기","면 넣기","스프 넣기","3분 대기","완성"};
		for(int cnt=0; cnt<=4; cnt++) {
			System.out.println(nuddle[cnt]);
		}
		/*
		 2. **🎮 게임 로그인 검사기 (자바)**  
   			- 사용자에게 ID와 비밀번호를 입력받고, ID는 `"gamer01"`, 비밀번호는 `"pass123"`일 때 로그인 성공 메시지를 출력하세요. 그 외는 실패 메시지를 출력하세요.
		 */
		Scanner sc = new Scanner(System.in);
		System.out.print("Id : ");
		String id = sc.nextLine();
		System.out.print("Password : ");
		String password = sc.nextLine();

		if(id.equals("gamer01") && password.equals("pass123")) {
			System.out.println("로그인 성공");
		}else {
			System.out.println("실패");
		}
		/*
		 5. **🎲 주사위 시뮬레이터 (자바)**  
   			- `Math.random()`을 사용하여 1~6 사이의 주사위 숫자를 생성하고, "주사위 눈은 @@입니다!" 라고 출력하는 코드를 작성하세요.
		 */
		int ran = (int)(Math.random()*6+1);
		System.out.println("주사위 눈은 "+ran+"입니다");

	}

}
