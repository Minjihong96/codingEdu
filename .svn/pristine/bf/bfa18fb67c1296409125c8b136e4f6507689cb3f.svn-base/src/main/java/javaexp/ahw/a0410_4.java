package javaexp.ahw;

public class a0410_4 {
	
	static void pro(String name, int num, String name1) {
		System.out.println("상품명 :"+name);
		System.out.println("개수 : "+num);
		System.out.println("포장 종류 : "+name1);
		
	}

	public static void main(String[] args) {
		
		pro("스마트폰", 1, "박스포장");

	}

}
