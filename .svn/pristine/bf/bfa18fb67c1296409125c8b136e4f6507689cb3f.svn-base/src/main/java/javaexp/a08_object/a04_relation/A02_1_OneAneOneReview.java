package javaexp.a08_object.a04_relation;

public class A02_1_OneAneOneReview {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Friend fi01 = new Friend("민수");
		FriendHouse fh01 = new FriendHouse("서울시 강남구",fi01);
		fh01.introduceHouse();
		/*
		# 동작
		1. FriendHouse 클래스 : 친구의 집을 나타내는 클래스 이 집은 주소(address)와 집주인친구(myFriend)를 가진다.
		2. Friend 클래스 : 친구를 나타내는 클래스. 이 친구는 이름(name)을 가집니다.
		3. main() 클래스 : 프로그램을 실행하는부분으로, 친구와 친구의 집을 만들고 서로 연결합니다.
		# 과정
		1. 친구를 만들다 : Friend fi01 = new Friend("민수");
		2. 친구의 집을 만들다 : FriendHouse fh01 = new FriendHouse("서울시 강남구",fi01);
		3. 친구와 집을 소개 하다. : fh01.introduceHouse();
		*/
		King k01 = new King("숙종(왕)");
		Kingdom kd01 = new Kingdom("조선",k01);
		// kd01.name = "조선";
		// kd01.king.name = "숙종(왕)";
		kd01.showKing();
		System.out.println("왕국의 이름은 : "+kd01.getName());
		System.out.println("왕의 이름은 : "+kd01.getKing().getName());
		
		Director dt01 = new Director("스티븐 스필버그");
		Movie mv01 = new Movie("스타워즈",dt01);
		System.out.println("영화 타이틀 : "+mv01.getTitle());
		System.out.println("감독 이름 : "+mv01.getDirector().getName());
		
		
	}

}
// 영화와 감독
class Director{
	private String name;

	public Director() {
		// TODO Auto-generated constructor stub
	}

	public Director(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
class Movie{
	private String title;
	private Director director;
	public Movie(String title, Director director) {
		this.title = title;
		this.director = director;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Director getDirector() {
		return director;
	}
	public void setDirector(Director director) {
		this.director = director;
	}
	
}
// 왕 클래스
class King{
	private String name;

	public King(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
// 왕을 포함한 클래스
class Kingdom{
	private String name;
	private King king;
	public Kingdom(String name, King king) {
		this.name = name;
		this.king = king;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public King getKing() {
		return king;
	}
	public void setKing(King king) {
		this.king = king;
	}
	public void showKing() {
		System.out.println("나라 : "+name);
		System.out.println("왕 : "+king.getName());
	}
	
}
/*
# 1:1 객체 관계로 친구와 집을 연결하는 이야기
1. 관계란 ?
	한 친구는 하나의 집을 가지고, 하나의 집은 한 친구만을 가진다는 개념입니다.
	1) 한 친구는 하나의 집만 가지고 있습니다.
	2) 한 집에는 한 친구만 살고 있습니다.
2. 친구와 집을 연결하는 class
	1) Friend 친구 클래스
	2) House 집 클래스(필드 address, Friend 객체)
	
*/
class Friend{ // 친구의 정보를 관리하는 상자
	private String name; // 친구의 이름 - 아무나 확인할 수 없음

	public Friend() {
		// TODO Auto-generated constructor stub
	}

	public Friend(String name) { // 친구의 이름을 초기에 설정
		this.name = name;
	}

	public String getName() { // 친구의 이름을 가져오는 열쇠
		return name;
	}

	public void setName(String name) { // 친구의 이름을 저장하는 열쇠
		this.name = name;
	}
	
}
class FriendHouse{ // 친구의 집 정보를 관리하는 상자
	private String address; // 집의 주소를 아무나 접근 못하게 처리
	private Friend myFriend; // 친구도 아무나 접근 못하게 처리
	public FriendHouse() {
		// TODO Auto-generated constructor stub
	}
	public FriendHouse(String address, Friend myFriend) { // 친구의 집을 만들 때, 주소와 친구객체를 설정
		this.address = address;
		this.myFriend = myFriend;
	}
	public String getAddress() { // 주소정보를 가져오는 열쇠
		return address;
	}
	public void setAddress(String address) { // 주소정보를 저장하는 열쇠
		this.address = address;
	}
	public Friend getMyFriend() { // 친구정보를 가져오는 열쇠
		return myFriend;
	}
	public void setMyFriend(Friend myFriend) { // 친구정보를 저장하는 열쇠
		this.myFriend = myFriend;
	}
	// 친구의 정보와 집의 정보를 확인하는 메서드
	public void introduceHouse() {
		System.out.println("이 집의 주소는 "+address+"입니다. 집 주인의 이름은 "+myFriend.getName()+"입니다.");
		// +myFriend.getName() myFriend라는 friend객체가 가지고 있는 name은 함부로 접근이 불가능하지만
		// getName()이라는 열쇠를 통해서는 가능하다.
	}
}