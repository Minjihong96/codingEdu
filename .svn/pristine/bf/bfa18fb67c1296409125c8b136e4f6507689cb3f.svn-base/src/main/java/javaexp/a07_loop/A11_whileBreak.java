package javaexp.a07_loop;

import java.util.Scanner;

public class A11_whileBreak {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.print("좋아하는 과일명(종료시 Y) : ");
			String fruit = sc.nextLine();
			if(fruit.equals("Y")) {
				System.out.println("종료");
				break;
			}
			System.out.print("과일 갯수 : ");
			int num = Integer.parseInt(sc.nextLine());
			System.out.print("가격 : ");
			int price = Integer.parseInt(sc.nextLine());
			int tot = price*num;
			System.out.println("구매할 과일명 : "+fruit);
			System.out.println("과일 갯수 : "+num+"개");
			System.out.println("가격 : "+price+"원");
			System.out.println("총비용 : "+tot+"원");
		}

	}

}
