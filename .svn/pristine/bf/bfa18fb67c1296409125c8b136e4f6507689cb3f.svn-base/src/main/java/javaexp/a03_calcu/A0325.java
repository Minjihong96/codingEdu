package javaexp.a03_calcu;

public class A0325 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 두 정수형 변수를 선언 후, 더하기/빼기/곱하기/나누기 연산 결과를 각각 출력하는 프로그램을 작성하세요.
		 */
		int num1 = 10;
		int num2 = 5;
		int tot1= num1+num2;
		int tot2= num1-num2;
		int tot3= num1*num2;
		int tot4= num1/num2;
		System.out.println(num1+" + "+num2+" = "+tot1);
		System.out.println(num1+" - "+num2+" = "+tot2);
		System.out.println(num1+" × "+num2+" = "+tot3);
		System.out.println(num1+" ÷ "+num2+" = "+tot4);

	}

}
