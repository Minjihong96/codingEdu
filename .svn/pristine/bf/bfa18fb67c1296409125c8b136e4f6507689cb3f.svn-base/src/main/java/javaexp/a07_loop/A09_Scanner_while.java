package javaexp.a07_loop;

import java.util.Scanner;

public class A09_Scanner_while {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		Scanner를 통해서 반복문을 통한 입력 처리
		물건정보 3개를 입력 받아서 출력
		1. Scanner객체 생성
		2. while() 문 수행
		3. 입력 내용 처리 종료시는 Y 그외는 물건명 입력
			1) 등록할 물건명입력(종료시Y)
			2) 물건명 출력
		*/
		Scanner sc = new Scanner(System.in);
		String inputProd = "";
		while(!inputProd.equals("Y")) {
			System.out.print("물건명을 입력하세요 (종료시Y) ");
			inputProd = sc.nextLine();
			if(!inputProd.equals("Y")) {
				System.out.println("입력한 물건명 : "+inputProd);
			}
		}
		System.out.println("물건입력 처리 종료!!");

	}

}
