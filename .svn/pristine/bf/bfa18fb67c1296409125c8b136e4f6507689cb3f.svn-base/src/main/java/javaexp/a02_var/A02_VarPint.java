package javaexp.a02_var;

public class A02_VarPint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//변수 선언 : 데이터유형(정수-int) 변수의 이름;
		int no1;
		int no2;
		int no3;
		int no4;
		// 변수 할당 : 변수명 = 데이터;
		no1 = 10;
		no2 = 20;
		no3 = 30;
		no4 = 40;
		// 호출 및 출력
		System.out.println("no1 : "+no1);
		System.out.println("no2 : "+no2);
		System.out.println("no3 : "+no3);
		System.out.println("no4 : "+no4);
		int no5 = 50;
		System.out.println("no5 : "+no5);
		// A03_VarPrint.java
		// cnt1, cnt2, cnt3, cnt4 변수 선언과 할당 분리 해서 출력
		// cnt5 변수 선언할당 동시해서 출력하세요

	}

}
