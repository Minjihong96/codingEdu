package javaexp.a02_var;

public class A04_VarUsing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// # 변수의 사용.
		// 1. 출력처리
		int kor = 80;
		System.out.println("국어 점수:"+kor);
		// 2. 다른 변수에 재 할당
		int kor2 =kor;
		int kor3 =kor;
		int kor4 =kor;
		int kor5 =kor;
		// kor 변수를 kor2에 할당하여 처리
		System.out.println("두번쨰 국어 점수:"+kor2);
		System.out.println("세번쨰 국어 점수:"+kor3);
		System.out.println("네번쨰 국어 점수:"+kor4);
		System.out.println("다섯번쨰 국어 점수:"+kor5);

		// 3. 다른 변수에 연산에 할당
		
		// ex) eng라는 변수로 점수 90을 할당하고,
		//     eng2, eng3, eng4, eng5에 재할당후, 출력
		
		int eng = 90;
		int eng2 = eng;
		int eng3 = eng;
		int eng4 = eng;
		int eng5 = eng;
		
		System.out.println("eng : "+eng);
		System.out.println("eng2 : "+eng2);
		System.out.println("eng3 : "+eng3);
		System.out.println("eng4 : "+eng4);
		System.out.println("eng5 : "+eng5);
		
		int price = 3000; // 가격변수할당
		int cnt =5;       // 갯수변수 할당.
		int totpay = price*cnt; // 위 두개의 변수를 연산하여 출려
		System.out.println("총비용:"+totpay);
		// 국어 영어 수학 점수의 합산.
		int korpt = 70;
		int engpt = 80;
		int mathpt = 90;
		int scoreTot = korpt+engpt+mathpt;
		System.out.println("총 점수의 합산:"+scoreTot);
		
		int myMoney =50000;
		int withdrawPay =3000;
		int myRestMoney =myMoney-withdrawPay;
		System.out.println("현재 잔액:"+myRestMoney);
		
		/* ex1) 오늘의 지출금액을 총비용을 처리해봅시다.
		        지출금액(pay1, pay2, pay3)울 각각 할당하여 총 비용(payAll)울 변수로 선언하여,
		        출력하세요
		   ex2) 정사각형의 면적을 밑변(base)와 높이(height)룰 설정하여 area10(면적)을 구하영 출력
		   ex3) 친구들과 저녁식사를 하여 100000이 나왔을 때, 4명이 동일하게 더치패이 할 때 끔액을 출력
		*/
		
		int pay1 = 10000;
		int pay2 = 20000;
		int pay3 = 30000;
		int payAll = pay1+pay2+pay3;
		System.out.println("오늘의 지출 총비용 : "+payAll);
		
		int base = 10;
		int height = base;
		int area10 = base*height;
		System.out.println("정사각형의 면적 : "+area10);
		
		int wesd = 10000;
		int persion = 4;
		int douch = wesd/persion;
		System.out.println("저녁식사 더치페이 금액 : "+douch);
		

	}

}
