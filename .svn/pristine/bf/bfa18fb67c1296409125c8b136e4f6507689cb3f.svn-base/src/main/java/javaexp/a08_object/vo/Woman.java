package javaexp.a08_object.vo;

public class Woman {
	public int age;
}
