package javaexp.a03_calcu;

public class A0327hw {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//자판기에 커피가 10잔 있다고 가정하고, 커피를 한 잔 살 때마다 `잔수--` 처리 후 남은 잔수를 출력하세요.
		int coffe = 10;
		System.out.println("커피 처음 잔수 : "+coffe--);
		System.out.println("커피 남은 잔수 : "+coffe--);
		System.out.println("커피 남은 잔수 : "+coffe--);
		System.out.println("커피 남은 잔수 : "+coffe--);
		System.out.println("커피 남은 잔수 : "+coffe--);
		System.out.println("커피 남은 잔수 : "+coffe--);
		System.out.println("커피 남은 잔수 : "+coffe--);
		System.out.println("커피 남은 잔수 : "+coffe--);
		System.out.println("커피 남은 잔수 : "+coffe--);
		System.out.println("커피 남은 잔수 : "+coffe--);
		System.out.println("커피 남은 잔수 : "+coffe--);
		//사용자의 경험치를 변수 `exp`에 저장하고, `exp += 50`씩 증가하여 1000이 되면 "레벨업!"을 출력하세요.
		int exp=700;
		exp += 50;
		System.out.println("경험치 : "+exp);
		System.out.println("경험치 : "+(exp+=50));
		System.out.println("경험치 : "+(exp+=50));
		System.out.println("경험치 : "+(exp+=50));
		System.out.println("경험치 : "+(exp+=50));
		System.out.println("경험치 : "+(exp+=50));
		System.out.println("레벨업!");
		//사과 바구니에 3개의 사과가 있습니다. 사과 하나를 먹을 때마다 `--` 처리하며 몇 개 남았는지 출력해보세요.
		int apple01 = 3;
		System.out.println("사과 갯수 : "+apple01);
		System.out.println("남은 사과 갯수 : "+--apple01);
		System.out.println("남은 사과 갯수 : "+--apple01);
		System.out.println("남은 사과 갯수 : "+--apple01);
		//역기를 들 때, `중량 += 5`로 증가시키며 5세트 반복 출력해보세요. 시작 중량은 20kg입니다.
		int weight = 20;
		System.out.println("시작 중량 : "+weight);
		System.out.println("1번 중량 : "+(weight+=5));
		System.out.println("2번 중량 : "+(weight+=5));
		System.out.println("3번 중량 : "+(weight+=5));
		System.out.println("4번 중량 : "+(weight+=5));
		System.out.println("5번 중량 : "+(weight+=5));
		//하루 8잔의 물을 마셔야 합니다. 물을 마실 때마다 `count++` 처리하고, 마지막엔 "오늘 목표 달성!" 출력.
		int waterCnt = 0;
		System.out.println("마신 물의 잔 수 :"+waterCnt++);
		System.out.println("마신 물의 잔 수 :"+waterCnt++);
		System.out.println("마신 물의 잔 수 :"+waterCnt++);
		System.out.println("마신 물의 잔 수 :"+waterCnt++);
		System.out.println("마신 물의 잔 수 :"+waterCnt++);
		System.out.println("마신 물의 잔 수 :"+waterCnt++);
		System.out.println("마신 물의 잔 수 :"+waterCnt++);
		System.out.println("마신 물의 잔 수 :"+waterCnt++);
		System.out.println("마신 물의 잔 수 :"+waterCnt++);
		System.out.println("오늘 목표 달성!");
		//오늘과 어제의 미세먼지 농도를 입력하고, 어느 날이 더 나쁜지 비교하여 출력해보세요.
		double today = 35;
		double yesterday = 32;
		System.out.println("오늘의 미세먼지 농도 : "+today);
		System.out.println("어제의 미세먼지 농도 : "+yesterday);
		System.out.println("오늘이 어제 보다 미세먼지 농도가 높은가 "+(today>yesterday));
		//두 과목 점수를 비교하여 어느 과목이 점수가 더 높은지 출력하는 프로그램을 작성해보세요.
		int math1 = 80;
		int english1 = 75;
		System.out.println("수학 점수 : "+math1);
		System.out.println("영어 점수 : "+english1);
		System.out.println("두 과목 중 영어 점수가 더 높은가 : "+(math1<english1));
		//`책1`과 `책2`의 대출일 수를 입력받아, 연체 가능성이 더 높은 책을 판단해보세요.
		int book1 = 2;
		int book2 = 3;
		System.out.println("책1의 대출일 수 : "+book1);
		System.out.println("책2의 대출일 수 : "+book2);
		System.out.println("책1이 책2보다 연체 가능성이 더 높은가 : "+(book1>book2));
		//두 사람의 나이를 입력받고, 누가 더 나이가 많은지 출력하세요.
		int age1 = 50;
		int age2 = 73;
		System.out.println("사람1의 나이 : "+age1);
		System.out.println("사람2의 나이 : "+age2);
		System.out.println("사람2의 나이가 사람1보다 나이가 더많은가 ? "+(age2>age1));
		//`시간` 변수를 증가시키며 `요금 += 1000` 처리하여 5시간 주차 시 총 요금을 출력해보세요.
		int time = 0; int tax01=0;
		time++; tax01 += 1000;
		System.out.println(time+"시간 "+tax01+"주차요금");
		time++; tax01 += 1000;
		System.out.println(time+"시간 "+tax01+"주차요금");
		time++; tax01 += 1000;
		System.out.println(time+"시간 "+tax01+"주차요금");
		time++; tax01 += 1000;
		System.out.println(time+"시간 "+tax01+"주차요금");
		time++; tax01 += 1000;
		System.out.println(time+"시간 "+tax01+"주차요금");
		
		
		
	
		
		
		
		
		
		
		

	}

}
