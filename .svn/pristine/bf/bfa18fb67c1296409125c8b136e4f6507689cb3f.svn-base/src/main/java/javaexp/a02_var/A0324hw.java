package javaexp.a02_var;

public class A0324hw {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   int appleCount = 27;
		   int bearCount = 4;
		   System.out.println("정수 나눗셈 결과 : "+(appleCount/bearCount));
		   System.out.println("나머지 값 : "+(appleCount%bearCount));
		   System.out.println("실수 나눗셈 결과 : "+(appleCount/(double)bearCount));

	}

}
