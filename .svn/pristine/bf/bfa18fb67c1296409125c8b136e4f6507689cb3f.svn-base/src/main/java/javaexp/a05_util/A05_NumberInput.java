package javaexp.a05_util;

import java.util.Scanner;

public class A05_NumberInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("구매한 바나나의 갯 수 : ");
		int banana = sc.nextInt();
		System.out.print("구매한 오렌지의 갯 수 : ");
		int orange = sc.nextInt();
		int totFruit = banana+orange;
		System.out.println("구매한 총 과일의 갯 수 : "+totFruit);

	}

}
