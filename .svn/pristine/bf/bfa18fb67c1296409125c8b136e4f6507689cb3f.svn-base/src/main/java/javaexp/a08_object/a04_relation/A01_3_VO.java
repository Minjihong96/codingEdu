package javaexp.a08_object.a04_relation;

public class A01_3_VO {

	public static void main(String[] args) {
		
		// al01이라는 동물을 생성과 동시에 이름과 나이 할당
		Animal al01 = new Animal("짬타이거",8);
		System.out.println("이름 : "+al01.getName());
		System.out.println("나이 : "+al01.getAge());
		// 이름 변경
		al01.setName("돼냥이");
		System.out.println("이름 : "+al01.getName());
		System.out.println("나이 : "+al01.getAge());
		/*
		# 객체 생성 정리
		1. 클래스는 동물의 정보를 담는 상자
		2, 생성자는 동물을 만들 때, 이름과 나이를 주는 마법의 주문
		3. get/set메서드는 동물의 정보를 안전하게 바꾸거나 확인할 수 있는 열쇠 
		*/
	}

}
/*
# 동물을 관리하는 마법사가 되고, 동물들을 더 잘 관리하기 위해 특별한 규칙을 만들어야 합니다.
동물마다 이름과 나이가 있고, 이 정보를 아무도 못 바꾸게 보호해야 합니다.
1. 클래스 : 동물의 비밀을 담고 있는 상자 
	- 동물의 이름과 나이
2. 생성자 : 동물에게 이름과 나이를 주는 마법의 주문
	- 이름과 나이를 설정
3. get/set메서드 : 동물의 비밀을 안전하게 꺼내거나 바꾸는 열쇠
	밖에서는 바꿀 수 없습니다. 그래서 우리는 열쇠를 만들어 이름이나 나이를 바꿀 수 있게
*/
class Animal{
	private String name;
	private int age;
	public Animal(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}
