package javaexp.ahw;

public class a0415_1 {

	public static void main(String[] args) {
		Book b1 = new Book("백설공주","작가미상",300,45000);
		Book b2 = new Book("헨젤과 그레텔","작가미상",250,50000);
		System.out.println("# 도서 등록 #");
		System.out.println("책 제목 : "+b1.title);
		System.out.println("# 도서 등록 #");
		System.out.println("책 제목 : "+b2.title);

	}

}

class Book{
	String title;
	String name;
	int page;
	int price;
	Book(String title, String name, int page, int price){
		this.title=title;
		this.name=name;
		this.page=page;
		this.price=price;
	}
}