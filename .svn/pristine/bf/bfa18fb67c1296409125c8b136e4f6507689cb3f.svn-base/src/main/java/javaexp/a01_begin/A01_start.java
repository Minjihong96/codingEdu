package javaexp.a01_begin;

public class A01_start {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        // 주석 : 코드가 실행되지 않는 설명부분
		// ctrl + (+/-) 글자 크기 조절
		// ctrl + s : 저장
		// 대문자 소문자 구분 필요
		// System.out.println("출력할 내용");
		// f11 : 디버깅 단축키
		System.out.println("자바 시작합니다");
		
		
	}

}
