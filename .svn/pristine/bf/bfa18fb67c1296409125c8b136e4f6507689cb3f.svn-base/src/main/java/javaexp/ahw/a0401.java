package javaexp.ahw;

import java.util.Scanner;

public class a0401 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 1. 🧃 **"랜덤 음료 자판기" 만들기**  
   			자바에서 3가지 음료("콜라", "사이다", "주스") 중 하나가 랜덤으로 출력되게 하세요.
		 */
		String str[] = {"콜라", "사이다", "주스"};
		int ran = (int)(Math.random()*3);
		System.out.println("랜덤 음료 : "+str[ran]);
		/*
		 2. 🛍️ **"쇼핑 계산기" 만들기**  
   			사용자에게 물건명, 가격, 수량을 입력받고 총 구매 금액을 출력하는 프로그램을 작성하세요.
		 */
		
		Scanner sc = new Scanner(System.in);
		System.out.print("물건명 : ");
		String product = sc.nextLine();
		System.out.print("가격 : ");
		String price = sc.nextLine();
		System.out.print("수량 : ");
		String num = sc.nextLine();
		int tot = Integer.parseInt(price)*Integer.parseInt(num);
		System.out.println("총 구매 금액 : "+tot);
		
		

	}

}
