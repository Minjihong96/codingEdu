package javaexp.ahw;

public class a0408 {
	
	static int orderPizza(int price, int count) {
		System.out.println("피자 가격 : "+price);
		System.out.println("수량 : "+count);
		int tot = price*count;
		return tot;
	}

	public static void main(String[] args) {
		
		int pizza = orderPizza(25000,3);
		System.out.println("총 주문 금액 : "+pizza);

	}

}
