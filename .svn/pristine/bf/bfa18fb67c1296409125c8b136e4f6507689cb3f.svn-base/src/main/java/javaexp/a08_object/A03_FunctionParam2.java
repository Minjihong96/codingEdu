package javaexp.a08_object;

import java.util.Scanner;

public class A03_FunctionParam2 {
	
	/*
	 여러가지 매개변수와 이에 따른 처리
	 과목, 점수1, 점수2, 평균
	 */
	static void f1(String subject, int point1, int point2) {
		System.out.println("과목명 : "+subject);
		System.out.println("중간 : "+point1);
		System.out.println("기말 : "+point2);
		double avg = (point1+point2)/(double)2;
		System.out.println("최종점수(평균) : "+avg);
	}
	/*
	 사각형의 밑면과 높이를 매개변수를 받아서 면적을 출력하세요
	 */
	static void f2(double line, double height) {
		System.out.println("면적 : "+(line*height));
	}
	/*
	 물건명과 가격, 갯수, 할인율입력아서 최종 금액까지 출력
	 */
	static void f3() {
		Scanner sc = new Scanner(System.in);
		System.out.print("물건명 : ");
		String product = sc.nextLine();
		System.out.print("가격 : ");
		int price = Integer.parseInt(sc.nextLine());
		System.out.print("갯수 : ");
		int num1 = Integer.parseInt(sc.nextLine());
		System.out.print("할인율 : ");
		double sale = Double.parseDouble(sc.nextLine());
		double tot = price*(1-sale/100);
		int tot1 = (int)tot*(int)num1;
		System.out.println("물건명 : "+product+", 가격 : "+price+"원, 갯 수 : "+num1+"개, 할인율 : "+sale+"%");
		System.out.println("최종 금액 : "+tot1+"원");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		f1("국어",75,80);
		f1("영어",85,90);
		f2(80,75);
		f3();

	}

}
