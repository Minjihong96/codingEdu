package javaexp.a02_var;

public class A13_CastingDivide {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 # 자바에서 나눗셈 처리.
		 1. 자바는 정수형에서 정수형을 나누기를 하면 정수만 처리된다.
		     즉, 자동으로 casting 처리되어 실수형이 처리되지 않는다.
		     10/3 ==> 3 ps) 10%3 ==> 1 : 나머지 연산자에 의해 나머지값 처리
		 2. 자바에서 정수형에서 정수형으로 나눌 때, 소숫점이하까지 처리할려면
		    분모이든 분자이든 실수형으로 변환하여 처리하여 한다.
		    10/3.0 ==> 3.3333333...    (double)10/3 ==> 3.33333
		    10/(double)3 ==> 3.3333..
		    부모이든 분자이든 강제형변환 처리를 하여야지 원하는 소숫점이하 연산이 처리된다.
		    
		 */
		System.out.println("정수형의 나눗셈 처리");
		System.out.println("10/3 = "+(10/3));
		System.out.println("10%3 = "+(10%3));
		System.out.println("10/3.0 = "+(10/3.0));
		System.out.println("(double)10/3 = "+((double)10/3));
		System.out.println("10/(double)3 = "+(10/(double)3));
		
		// ex) 곰돌이의 마리수를 변수로 지정해서 할당하고(5마리), 사과의 갯수를 변수에 할당하여 지정하고(17개)
		// 위 연산식에 의해, 동일하게 나눈 갯수와 나머지 갯수를 출력하고,
		// 실수까지 동일하게 나눈 내용을 출력하세요
		
		int bearNum1 =5 ;
		int apple = 17;
		System.out.println("사과를 동일하게 나눈 갯수 = "+(apple/bearNum1));
		System.out.println("나머지 갯수 = "+(apple%bearNum1));
		double bearNum2 = bearNum1;
		System.out.println("사과를 동일하게 나눈 갯수 = "+(apple/bearNum2));
		System.out.println("사과를 동일하게 나눈 갯수 = "+(apple/(double)bearNum1));
		//자바에서는 정수형/정수형으로 나눌 때, 실수값까지 가져올려면 적어도 분모나 분자 둘중에 하나는 실수형이어야 하기에 ()타입개스트로 처리하다.
		
		

	}

}
