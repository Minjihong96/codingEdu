package javaexp.ahw;

import java.util.Scanner;

public class A0403 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 1. **🎟️ 영화관 티켓 등급 분류기 (자바 중첩 if)**  
   		- 나이와 관람 등급을 입력받아,  
     	- 18세 이상이고 등급이 "성인"이면 "관람 가능",  
     	- 18세 미만이면 "관람 불가",  
     	- 등급이 "전체"인 경우 누구나 "관람 가능"을 출력하세요.
		 
		 */
		Scanner sc = new Scanner(System.in);
		System.out.print("관람 등급 : ");
		String grade = sc.nextLine();
		System.out.print("나이 : ");
		int age = sc.nextInt();
		System.out.println("관람 등급 : "+grade);
		System.out.println("나이 : "+age);
		if(age>=18){
			if(grade.equals("성인")) {
				System.out.println("관람 가능");
			}
		}else if(grade.equals("전체")){
			System.out.println("관람 가능");
		}else {
			System.out.println("관람 불가");
		}

	}

}
