package javaexp.a05_util;

import java.util.Scanner;

public class A07_InputString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("학생의 이름 : ");
		String name = sc.nextLine();
		System.out.print("국어 점수 : ");
		String kor = sc.nextLine();
		System.out.print("영어 점수 : ");
		String eng = sc.nextLine();
		System.out.print("수학 점수 : ");
		String math = sc.nextLine();
		int tot = Integer.parseInt(kor) + Integer.parseInt(eng) + Integer.parseInt(math);
		double average = (double)tot/3;
		System.out.println("이름 : "+name);
		System.out.println("총점 : "+tot);
		System.out.println("평균 : "+average);
		

	}

}
