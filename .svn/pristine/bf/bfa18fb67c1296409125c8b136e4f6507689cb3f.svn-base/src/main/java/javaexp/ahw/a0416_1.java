package javaexp.ahw;

public class a0416_1 {

	public static void main(String[] args) {
		HamBurger hb1 = new HamBurger("불고기버거");
		HamBurger hb2 = new HamBurger("치즈버거");
		Cat c1 = new Cat();
		Cat c2 = new Cat("나비");
		Movie m1 = new Movie("기생충" ,"봉준호");

	}

}
class Movie{
	Movie(String title, String name){
		System.out.println("영화 제목 : "+title);
		System.out.println("영화 감독 : "+name);
	}
}
class Cat{
	String name;
	Cat(){
		System.out.println("이름 : 이름없음");;
	}
	Cat(String name){
		this.name=name;
		System.out.println("이름 : "+name);
	}
}
class HamBurger{
	String name;
	HamBurger(String name){
		this.name=name;
		printOrder();
	}
	void printOrder() {
		System.out.println(name);
	}
}
