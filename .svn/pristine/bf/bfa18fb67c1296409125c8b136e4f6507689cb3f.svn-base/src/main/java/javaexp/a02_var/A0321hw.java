package javaexp.a02_var;

public class A0321hw {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 double height =170.2;
		 double weight =68.4;
		 double bmi;
		 bmi= weight / (height * height) * 10000;
		 System.out.println("체질량 지수 : "+bmi);

	}

}
