package javaexp.ahw;

public class a0415_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CartItem ci1 =new CartItem("무선 이어폰");
		CartItem ci2 =new CartItem("키보드");
		System.out.println(ci1.name);
		System.out.println(ci2.name);

	}

}
class CartItem{
	String name;
	CartItem(String name){
		this.name=name;
	}
}
