package javaexp.a02_var;

public class A08_DeclareExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
### ✅ **실습 문제 1 — 잘못된 변수 찾기**  
아래 변수 선언 중 잘못된 것을 찾고, 이유를 주석으로 적어보세요!  
```java
int 1number;     
int _age;        
int class;       
int userName;    
int UserName;    
```
답은 int 1number; 변수 설정에서 숫자는 먼저 사용할 수 없다.
    int class; 내장된 키워드이기에 애러 발생
---

### ✅ **실습 문제 2 — 대소문자 구분 연습**  
아래 코드의 출력 결과가 무엇일지 생각해보고, 왜 그런지 설명해보세요!  
```java
int apple = 10;
int Apple = 20;
System.out.println(apple);  
System.out.println(Apple);
```
10
20
변수 설정에서 대문자 소문자 차이로 인해 각각의 변수가 설정되었다.
그러나, 가독성 문제가 발생 할 수 있다 Apple을 apple01로 변경하는 것을 권고
---

### ✅ **실습 문제 3 — 올바른 변수 이름으로 고쳐쓰기**  
다음 잘못된 변수 선언을 올바르게 수정해보세요.  
```java
int void;        // (예약어 사용 금지)
int 9count;      // (숫자로 시작 금지)
int first name;  // (공백 사용 불가)
```
int void01;
int count9;
int first_name;
---

### ✅ **실습 문제 4 — 내가 만드는 변수 이름 퀴즈**  
다음 조건에 맞게 스스로 변수명을 만들어 선언해보세요!  
1. 내 나이를 저장할 변수  
2. 나의 키(cm)를 저장할 변수  
3. 좋아하는 음식 이름을 저장할 변수  
4. 오늘의 날씨 상태를 저장할 변수 (boolean)

1. int age;
2. double stature;
3. String food;
4. boolean weather;
---

### ✅ **실습 문제 5 — 클래스명과 변수명 구분 연습**  
아래 보기 중 클래스 이름으로 적합한 것과 변수 이름으로 적합한 것을 구분해보세요.  
```
1) Animal     
2) studentAge  
3) House      
4) maxValue   
5) Circle      
6) total_count 

클래스는 대문자 시작이 좋다.  클래스 : 1) 3) 5) 
변수 설정은 보통 소문자       변수 : 2) 4) 6)
		 */
	}

}
