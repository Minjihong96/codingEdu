package javaexp.a08_object.vo;

public class PizzaOrder {
	private String customerName;
	private String pizzaType;
	private String size;
	private boolean extraCheese;
	public PizzaOrder() {
		// TODO Auto-generated constructor stub
	}
	public PizzaOrder(String customerName, String pizzaType, String size, boolean extraCheese) {
		this.customerName = customerName;
		this.pizzaType = pizzaType;
		this.size = size;
		this.extraCheese = extraCheese;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPizzaType() {
		return pizzaType;
	}
	public void setPizzaType(String pizzaType) {
		this.pizzaType = pizzaType;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public boolean isExtraCheese() {
		return extraCheese;
	}
	public void setExtraCheese(boolean extraCheese) {
		this.extraCheese = extraCheese;
	}
	
}
