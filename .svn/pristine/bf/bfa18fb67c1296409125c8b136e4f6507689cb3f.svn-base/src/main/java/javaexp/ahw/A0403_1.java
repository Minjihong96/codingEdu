package javaexp.ahw;

public class A0403_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int ran = (int)(Math.random()*5+1);
		System.out.println("나온 숫자 : "+ran);
		switch(ran) {
			case 1:
			case 2:
			case 4:
			case 5:
				System.out.println("오답!");
				break;
			case 3:
				System.out.println("정답!");
				break;
			default:
				System.out.println("오답!");
		}

	}

}
