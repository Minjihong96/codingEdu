package javaexp.ahw;

import java.util.Scanner;

public class a0410_1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("도넛 이름 : ");
		String name = sc.nextLine();
		System.out.print("가격 : ");
		int price = Integer.parseInt(sc.nextLine());
		System.out.print("수량 : ");
		int num = Integer.parseInt(sc.nextLine());
		int tot = price*num;
		System.out.println("도넛 이름 : "+name);
		System.out.println("가격 : "+price);
		System.out.println("수량 : "+num);
		System.out.println("총금액 : "+tot);

	}

}
