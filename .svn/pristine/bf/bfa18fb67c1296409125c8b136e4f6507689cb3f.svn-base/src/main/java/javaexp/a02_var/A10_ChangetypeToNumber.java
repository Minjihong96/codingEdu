package javaexp.a02_var;

public class A10_ChangetypeToNumber {

	public static void main(String[] args) {
		
		System.out.println("문자열 출력");
		/*
		 # 문자열에서 숫자형으로 형변환
		 1. 일반적으로 문자열 데이터를 숫자로 바꾸어야 연산이 가능하다.
		 2. 이러한 형태를 프로그램에서 많이 활용되므로 처리하여야 한다.
		 3. 기본 형식
		     String str01 = "25"; // 문자열형 25
		     int num01 = Integer.parseInt(str01);
		     Integer라는 wrapper 클래스의 기능메서드 parseInt()에 매개변수로 해당 숫자형 문자열("25")를 할당하면
		     숫자(정수)로 변경이 되어, int num01에 할당할 수 있다.
		 */
		
		String str01 ="25";
		int num01 = Integer.parseInt(str01);
		System.out.println(str01 + 5);
		System.out.println(num01 + 5);
		
		/*
		 ex) str02로 숫자형 문자열 "55"할당하고, int num02로 위와 형변환하여 할당한후,
		     str02+10,num02+10 하여 출력     
		 */
		
		String str02 = "55";
		int num02 = Integer.parseInt(str02);
		System.out.println(str02 + 10);
		System.out.println(num02 + 10);

	}

}
