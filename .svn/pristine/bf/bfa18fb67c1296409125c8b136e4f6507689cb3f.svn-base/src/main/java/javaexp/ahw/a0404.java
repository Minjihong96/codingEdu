package javaexp.ahw;

public class a0404 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 1. **🎁 보물찾기 게임 (자바)**  
   			- 1~10번 상자 중 무작위 번호에 보물이 숨겨져 있습니다.  
   			- `for`문을 사용하여 상자를 차례대로 열고, 정답 상자에서 `break`로 종료합니다.  
   			- 상자 열 때 `"X번 상자 열기..."` / 보물 찾으면 `"보물 발견!"` 출력하세요.
		 */
		for(int cnt=1;cnt<=10;cnt++) {
			System.out.println(cnt+"번 상자 열기");
			int ran=(int)(Math.random()*10+1);
			if(cnt==ran) {
				System.out.println("보물발견");
				break;
			}
		}
		/*
		 2. **💣 지뢰찾기 (자바 + continue)**  
   			- 1~10까지 번호 중 3, 7은 지뢰입니다.  
   			- 번호를 순회하며 `"X번 칸 안전"` 또는 `"지뢰 발견! 지나가기"` 출력 (continue 사용)
		 */
		for(int cnt=1;cnt<=10;cnt++) {
			System.out.println(cnt+"번 칸 안전");
			if(cnt==3||cnt==7) {
				System.out.println("지뢰 발견! 지나가기");
				continue;
			}
		}

	}

}
