package javaexp.a10_database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javaexp.a10_database.dto.Emp;

// import="javaexp.a10_database.A03_ExpDao"
// import="javaexp.a10_database.dto.Emp"
public class A03_ExpDao {	
	// SELECT 템플릿
	public List<Emp> getSelectTmp(Emp sch){
		List<Emp> list  = new ArrayList<Emp>();
		String sql = "SELECT * FROM EMP10 WHERE ENAME LIKE ?";
		try(Connection con = DB.con();
			PreparedStatement pstmt = con.prepareStatement(sql);){
			pstmt.setString(1, "%"+sch.getEname()+"%");
			try(ResultSet rs = pstmt.executeQuery()){
				while(rs.next()) {   
					list.add(new Emp(rs.getInt("EMPNO"),rs.getString("ENAME"),rs.getString("JOB"),rs.getInt("MGR"),
									rs.getDate("HIREDATE"),rs.getDouble("SAL"),rs.getDouble("COMM"),rs.getInt("DEPTNO") ));
				}
				System.out.println("데이터 로딩 완료:"+list.size());				
			}
		}catch(SQLException e) {
			System.out.println("DB처리 에러:"+e.getMessage());
		}catch(Exception e) {
			System.out.println("기타 에러:"+e.getMessage());
		}
		return list;
	}
	
	public String getEnameByEmpno(int empno) {
		String ename = "";
		String sql ="SELECT ENAME FROM EMP WHERE EMPNO=?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setInt(1, empno); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					if(rs.next()) {   // 한개 행 리턴
						ename=rs.getString("ENAME");
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return ename;
	}
	
	public String getJobByEname(String ename) {
		String job = null;
		String sql ="SELECT JOB FROM EMP10 WHERE ENAME =?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setString(1, ename); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					if(rs.next()) {   // 한개 행 리턴
						job=rs.getString("JOB");
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return job;
	}
	// ex) 사원번호(empno)이 사원의 급여를 구하는 sql과 메서드를 선언해보세요
	public double getSalByEmpno(int empno) {
		double sal = 0;
		String sql ="SELECT SAL FROM EMP10 WHERE EMPNO=?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setInt(1, empno); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					if(rs.next()) {   // 한개 행 리턴
						sal=rs.getDouble("SAL");
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return sal;
		
	}
	
	public double getSalByEname(String ename) {
		double sal = 0;
		String sql ="SELECT SAL FROM EMP10 WHERE ENAME=?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setString(1, ename); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					if(rs.next()) {   // 한개 행 리턴
						sal=rs.getDouble("SAL");
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return sal;
		
	}
	public String getEnameBySal(double sal) {
		String ename=null;
		String sql ="SELECT ENAME FROM EMP10 WHERE SAL=?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setDouble(1, sal); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					if(rs.next()) {   // 한개 행 리턴
						ename=rs.getString("ENAME");
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return ename;
	}
	public String getDnameByDeptno(int deptno){
		String dname = "";
		String sql = "SELECT DNAME FROM DEPT WHERE DEPTNO = ?";
		try(Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setInt(1, deptno);
				try(ResultSet rs = pstmt.executeQuery()){
					if(rs.next()) {   
						dname=rs.getString("DNAME");
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		return dname;
	}

	public List<String> getEnamesByDeptno(int deptno){
		List<String> enameList = new ArrayList<String>();
		String sql="SELECT ENAME FROM EMP10 WHERE DEPTNO = ?";
		try(Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setInt(1, deptno);
				try(ResultSet rs = pstmt.executeQuery()){
					while(rs.next()) {   
						enameList.add(rs.getString("ENAME"));
					}
					System.out.println("데이터 로딩 완료:"+enameList.size());				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return enameList; 
	} 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 7654 입력했을 때, 나올 사원명 확인
		A03_ExpDao dao = new A03_ExpDao();
		for(String ename:dao.getEnamesByDeptno(10)) {
			System.out.println(ename);
		}
		for(String ename:dao.getEnamesByDeptno(30)) {
			System.out.println(ename);
		}
		System.out.println(dao.getEnamesByDeptno(10));
		System.out.println(dao.getDnameByDeptno(10));
		System.out.println(dao.getEnameByEmpno(7654));
		System.out.println(dao.getJobByEname("ALLEN"));
		System.out.println(dao.getSalByEmpno(7369));
		System.out.println(dao.getEnameBySal(800));

	}

}
