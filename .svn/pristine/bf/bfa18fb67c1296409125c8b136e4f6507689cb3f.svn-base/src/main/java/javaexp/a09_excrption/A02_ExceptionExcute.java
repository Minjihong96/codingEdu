package javaexp.a09_excrption;

public class A02_ExceptionExcute {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("시작");
		// ArithmeticException
		try{
			for(int cnt=5;cnt>=-5;cnt--) {
				System.out.println(1/cnt);
			}
			
		}catch(ArithmeticException e){ //예외가 발생시 처리할 내용 블럭
			System.out.println("# 예외 발생 #");
			System.out.println(e.getMessage()); //: 해당 예외의 내용을 처리해서 그 메시지 내용을 출력하는 내장된 Exception의 기능메서드.
		}
		System.out.println("종료");
		
		// 연습 예제
		// NullPointerException
		System.out.println("# 문자열 처리 프로그램 #");
		try {
			String str = null;
			System.out.println("문자열 길이 : " + str.length());
		}catch(NullPointerException e) {
			System.out.println("# 예외 발생 #");
			System.out.println(e.getMessage());
		}
		System.out.println("# 문자열 처리 프로그램 종료 #");
	}

}
