package javaexp.a06_condition;

import java.util.Scanner;

public class A07_Nestedif_login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("로그인");
		System.out.print("id : ");
		String id = sc.nextLine();
		System.out.print("password : ");
		String psw = sc.nextLine();
		if(id.equals("himan")) {
			if(psw.equals("7777")) {
				System.out.println("로그인");
			}else {
				System.out.println("비밀번호가 틀렸습니다.");
			}
		}else {
			System.out.println("id가 틀렸습니다.");
		}
		/*
		if(true) {
         	if(true){
            	// 경우1
         	}else{
            	// 경우2
        	}
      	}else {
         	if(true) {
            	// 경우3
         	}else {
            	// 경우4
         	}         
      	}
      	입렵 받는 문자가 여러가지일 경우 처음에 받는 입력값이 정수나 실수 일 경우, 
      	뒤에 받는 입력 값이 문자열일 경우 오류가 발생 할 수 있다.
      	이 같은 경우 처음 받는 입력값을 정수나 실수로 받는 것이 아닌 문자열로 받아서 값을 형변환 해주는 것이 오류를 줄일 수 있다. 
		 */

	}

}
