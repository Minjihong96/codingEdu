package javaexp.a08_object.a01classOb;

public class A12_ObjectMethodAll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Hero hr1 = new Hero("길가메쉬",100);
			hr1.greet();
			hr1.userPotion(10);
			hr1.attack(30);
			hr1.getCurHp();
	}

}
class Hero{
	String name;
	int hp;
	public Hero(String name, int hp) {
		this.name = name;
		this.hp = hp;
	}
	void greet() {
		System.out.println(name+"가 인사합니다.");
	}
	void userPotion(int healAmount) {
		System.out.println(name+"가 체력이 "+healAmount+"hp회복되었습니다.");
		this.hp += healAmount;
	}
	void attack(int attack) {
		this.hp -= attack;
		System.out.println(name+"가 싸우다가 "+attack+"hp감소했습니다.");
	}
	void getCurHp() {
		System.out.println("현재 남은 hp : "+hp);
	}
}