package javaexp.a07_loop;

import java.util.Scanner;

public class A08_ScannerWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 물건명 :  가격 : 갯수 : 를 입력(해당라인에서 print())
		Scanner sc = new Scanner(System.in);
		System.out.print("물건명 : ");
		String product = sc.nextLine();
		System.out.print("가격 : ");
		int money = Integer.parseInt(sc.nextLine());
		System.out.print("갯수 : ");
		int num = Integer.parseInt(sc.nextLine());
		System.out.println("물건명 : "+product+", 가격 : "+money+"원, 갯수 : "+num);
		int total = money*num;
		System.out.println("총비용 : "+total+"원");

	}

}
