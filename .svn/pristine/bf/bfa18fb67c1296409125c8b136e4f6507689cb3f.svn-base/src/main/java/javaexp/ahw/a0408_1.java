package javaexp.ahw;

public class a0408_1 {
	
	static int dice() {
		int ran = (int)(Math.random()*6+1);
		return ran;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ran1 = dice();
		int ran2 = dice();
		System.out.println("플레이어 1의 주사위 : "+ran1);
		System.out.println("플레이어 2의 주사위 : "+ran2);
		if(ran1>ran2) {
			System.out.println("플레이어1 승리");
		}else if(ran1==ran2) {
			System.out.println("무승부");
		}else {
			System.out.println("플레이어2 승리");
		}
	}

}
