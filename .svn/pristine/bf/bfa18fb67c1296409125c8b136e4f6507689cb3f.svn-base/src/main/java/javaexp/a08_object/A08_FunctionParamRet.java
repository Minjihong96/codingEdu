package javaexp.a08_object;

public class A08_FunctionParamRet {
	
	/*
	 매개변수와 리턴값을 같이 사용하는 함수 처리
	 1. 합산처리 함수  두개의 정수값을 전달해서 합산된 값을 리턴하는 함수
	 */
	static int plus(int no1, int no2) {
		System.out.println("# 합산 처리 함수 #");
		System.out.println("매개변수값1 : "+no1);
		System.out.println("매개변수값2 : "+no2);
		int sum = no1 + no2;
		return sum;
	}
	// ex) discount 입금을 했을 때, 할인율 15%가 적용된 금액을 리턴처리하세요
	static double discount(int money) {
		System.out.println("# 할인 처리된 금액 #");
		System.out.println("현금 입금 : "+money);
		System.out.println("할인율 : 15%");
		double sale = money - (money*0.15);
		return sale;
	}
	// ex) buy() 매서드로 구매 가격과 구매 갯수를 입력 받아서 총 비용을 리턴하는  함수를 정의하고,
	//     해당 함수를 호출하여 최종금액을 출력
	static int buy(int money, int num) {
		int tot = money*num;
		System.out.println("#  구매 금액  #");
		System.out.println("구매 가격 : "+money);
		System.out.println("구매 갯수 : "+num);
		return tot;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("합산된 리턴값 : "+plus(5,4));
		int tot = plus(3,4);
		System.out.println("변수로 할당한 값 : "+tot);
		
		System.out.println(discount(10000)+"원");
		int sale = (int)discount(99999);
		System.out.println("정수로 변환된 금액 : "+sale+"원");
		
		System.out.println("최종 금액 : "+buy(10000,3));

	}

}
