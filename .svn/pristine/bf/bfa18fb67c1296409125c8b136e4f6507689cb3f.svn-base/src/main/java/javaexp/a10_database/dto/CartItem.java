package javaexp.a10_database.dto;

import java.util.Date;

public class CartItem {
	private int cart_id;
	private int user_id;
	private String product_name;
	private int quantity;
	private int price_per_item;
	private Date added_date;
	public CartItem() {
		// TODO Auto-generated constructor stub
	}
	public CartItem(int cart_id, int user_id, String product_name, int quantity, int price_per_item, Date added_date) {
		this.cart_id = cart_id;
		this.user_id = user_id;
		this.product_name = product_name;
		this.quantity = quantity;
		this.price_per_item = price_per_item;
		this.added_date = added_date;
	}
	public int getCart_id() {
		return cart_id;
	}
	public void setCart_id(int cart_id) {
		this.cart_id = cart_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getPrice_per_item() {
		return price_per_item;
	}
	public void setPrice_per_item(int price_per_item) {
		this.price_per_item = price_per_item;
	}
	public Date getAdded_date() {
		return added_date;
	}
	public void setAdded_date(Date added_date) {
		this.added_date = added_date;
	}
	
}
