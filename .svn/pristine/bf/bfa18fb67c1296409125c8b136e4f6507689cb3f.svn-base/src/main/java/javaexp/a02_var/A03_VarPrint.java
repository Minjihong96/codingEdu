package javaexp.a02_var;

public class A03_VarPrint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double cnt1;
		double cnt2;
		double cnt3;
		double cnt4;
		cnt1 = 10.0;
		cnt2 = 20.0;
		cnt3 = 30.0;
		cnt4 = 40.0;
		double cnt5 = 50.0;
		System.out.println("cnt1 : "+cnt1);
		System.out.println("cnt2 : "+cnt2);
		System.out.println("cnt3 : "+cnt3);
		System.out.println("cnt4 : "+cnt4);
		System.out.println("cnt5 : "+cnt5);

	}

}
