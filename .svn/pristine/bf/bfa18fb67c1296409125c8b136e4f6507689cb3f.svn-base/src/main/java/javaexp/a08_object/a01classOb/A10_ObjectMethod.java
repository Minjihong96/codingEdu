package javaexp.a08_object.a01classOb;

public class A10_ObjectMethod {

	public static void main(String[] args) {
		UserProfile up1 = new UserProfile("홍길동",25);
		up1.showProfile();
		up1.updateStatus("휴식중");
		up1.showProfile();
		Stud st1 = new Stud("이기찬");
		st1.showStudInf();
		st1.updateGrade("A");
		st1.showStudInf();
		Product pr1 = new Product("사과","50000");
		pr1.showproduct();
		pr1.updatePrice("4000");
		pr1.showproduct();
	}

}
class Product{
	String productName;
	String price;
	public Product(String productName, String price) {
		this.productName = productName;
		this.price = price;
	}
	void showproduct() {
		System.out.println("# 물건 정보 출력 #");
		System.out.println("물건명 : "+productName);
		System.out.println("물건가격 : "+price);
	}
	void updatePrice(String price) {
		this.price=price;
		System.out.println(productName+"의 가격 변경 : "+price+"원");
	}
}
class Stud{
	String name;
	String grade;
	public Stud(String name) {
		this.name = name;
		grade="c";
	}
	void updateGrade(String grade){
		this.grade=grade;
		System.out.println(name+"의 성적등급이 "+grade+"로 수정되었습니다.");
	}
	void showStudInf() {
		System.out.println("# "+name+"의 성적등급 #");
		System.out.println("성적등급 : "+grade);
	}
	
}
// 문자열이나 다른 유형으로 객체의 메서드의 ㅁ개변수로 받는 유형들.
class UserProfile{
	String userName;
	int age;
	String status;
	public UserProfile(String userName, int age) {
		this.userName = userName;
		this.age = age;
		status = "황동 중";
	}
	void updateStatus(String status) {
		this.status = status;
		System.out.println(userName+"의 상태가 "+status+"로 수정되었습니다.");
	}
	void showProfile() {
		System.out.println("# "+userName+"의 프로파일 #");
		System.out.println("나이 : "+age+"세");
		System.out.println("현재 상태 : "+status);
	}
}
