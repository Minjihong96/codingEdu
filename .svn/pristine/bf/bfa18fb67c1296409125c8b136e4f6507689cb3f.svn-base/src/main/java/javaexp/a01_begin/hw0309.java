package javaexp.a01_begin;

public class hw0309 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age=25;
	    String name="홍길동";
	    String hobby="독서";
	    System.out.println("저는 "+age+"살의 "+name+"이고, 취미는 "+hobby+"입니다.");
	    
	    int a=30;
	    int b=20;   
	       System.out.println("덧셈 결과 : "+(a+b));
	       System.out.println("뺄셈 결과 : "+(a-b));
	       System.out.println("곱셈 결과 : "+(a*b));
	       System.out.println("나눗셈 결과 : "+(a/b));
	}

}
