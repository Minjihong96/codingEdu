package javaexp.a02_var;

public class A07_DeclareRule {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 # 변수명 선언규칙
		 1. 필수 : 규칙대로 하지 않으면 애러발생
		     1) 선언된 변수는 다시 선언하지 않는다.
		     2) 첫번째 글자는 문자이거나 $,_이어야 하고, 숫자로 시작 할 수 없다.
		     3) 자바의 예약어(명령어)는 사용할 수 없다.
		         break, if 등
		         예외) int if01; 같이 뒤에 번호를 붙이는 순간 명령어에서 벗어 난다.
		     4) 변수를 대소문자를 구분한다.
		         int No1;
		         int no1;
		         int nO1;
		         ==>다 다른변수로 인식한다.
		 2. 관례 : 가독성에 의해서 준수할 것을 권유한다.
		     1) 기본 변수명을 소문자로 시작해서, 합성어의 경우 _, 대문자로 구분한다.
		         int setName;
		         int ser_name;
		     2) 클래스명은 대문자 시작한다. 자바는 객체의 경우 대문자로 시작한다.
		         매서드명, 변수명은 소문자로 시작.
		 
		 */

	}

}
