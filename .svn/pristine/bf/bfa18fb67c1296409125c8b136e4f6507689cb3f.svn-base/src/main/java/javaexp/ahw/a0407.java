package javaexp.ahw;

import java.util.Scanner;

public class a0407 {
	/*
	 1. **🛍️ 쇼핑 계산기 만들기**  
   - 물건명, 가격, 수량을 사용자에게 입력받아 총 금액을 출력하는 프로그램을 작성하세요. (입력: Scanner 사용)

	2. **🍎 과일 등록기**  
   - `while`문을 사용해 과일 이름을 반복 입력받고, 입력값이 "Y"이면 종료하세요. 그 외에는 입력한 과일명을 출력하세요.

	3. **🎲 주사위 시뮬레이터 함수 만들기**  
   - `Math.random()`을 사용해 1~6 사이의 숫자를 생성하는 `int` 리턴 함수를 작성하세요.

	4. **📐 직사각형 면적 계산 함수**  
   - 두 개의 정수형 매개변수를 받아 직사각형의 면적을 출력하는 메서드를 작성하세요.

	5. **📢 인사 메시지 함수**  
   - 매개변수 없이 "오늘도 좋은 날입니다!"를 3번 출력하는 메서드를 작성하세요.
	 */
	static void f1() {
		Scanner sc = new Scanner(System.in);
		System.out.print("물건명 : ");
		String product = sc.nextLine();
		System.out.print("가격 : ");
		int price = Integer.parseInt(sc.nextLine());
		System.out.print("갯수 : ");
		int num1 = Integer.parseInt(sc.nextLine());
		System.out.print("할인율 : ");
		double sale = Double.parseDouble(sc.nextLine());
		double tot = price*(1-sale/100);
		int tot1 = (int)tot*(int)num1;
		System.out.println("물건명 : "+product+", 가격 : "+price+"원, 갯 수 : "+num1+"개, 할인율 : "+sale+"%");
		System.out.println("최종 금액 : "+tot1+"원");
		
	}
	static int f2() {
		int ran = (int)(Math.random()*6+1);
		return ran;
	}
	static void f3(int line, int height) {
		int area = line*height;
		System.out.println("직사각형의 면적 : "+area);
	}
	static void f4() {
		System.out.println("오늘도 좋은 날입니다!");
		System.out.println("오늘도 좋은 날입니다!");
		System.out.println("오늘도 좋은 날입니다!");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		f1();
		System.out.println(f2());
		f3(10,50);
		f4();
		
	}

}
