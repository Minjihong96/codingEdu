package javaexp.ahw;

public class a0421 {

	public static void main(String[] args) {
		CleanBot cb =new CleanBot("클린봇A","도서관");
		cb.reportStatus();
		cb.clean("10레벨");
		cb.reportStatus();
		DroneDelivery dd = new DroneDelivery("드론x","강릉");
		dd.status();
		dd.deliver(3);
		dd.status();
		Chef cf = new Chef("안성재","도토리묵");
		cf.showChefInfo();
		cf.updateScore(85);
		cf.showChefInfo();
		
	}

}
class CleanBot{
	String botName;
	String cleanArea;
	String dustLevel;
	public CleanBot(String botName, String cleanArea) {
		this.botName = botName;
		this.cleanArea = cleanArea;
		dustLevel = "30레벨";
	}
	void clean(String dustLevel) {
		this.dustLevel = dustLevel;
		System.out.println("청소 후 먼지 : "+dustLevel);
	}
	void reportStatus() {
		System.out.println(botName+"가 "+cleanArea+"에서 먼지를 청소 : "+dustLevel);
	}
	
}
class DroneDelivery{
	String droneId;
	String location;
	int deliveryCount;
	public DroneDelivery(String droneId, String location) {
		this.droneId = droneId;
		this.location = location;
	}
	void deliver(int deliveryCount) {
		this.deliveryCount+=deliveryCount;
		System.out.println("배달 횟수 : "+deliveryCount);
	}
	void status() {
		System.out.println(droneId+"가 "+location+"에서 "+deliveryCount+"건을 배달");
	}
	
}
class Chef{
	String name;
	String specialDish;
	int score;
	public Chef(String name, String specialDish) {
		this.name = name;
		this.specialDish = specialDish;
	}
	void updateScore(int point) {
		this.score = point;
		System.out.println("얻은 점수 : "+point);
	}
	void showChefInfo() {
		System.out.println(name+"이 "+specialDish+"으로 점수 "+score+"점을 얻음");
	}
}
