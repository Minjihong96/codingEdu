package javaexp.a08_object.vo;

import java.util.Date;

public class Passport {
	private int passport;
	private String name;
	private Date date;
	public Passport() {
		// TODO Auto-generated constructor stub
	}
	public Passport(int passport, String name, Date date) {
		this.passport = passport;
		this.name = name;
		this.date = date;
	}
	public int getPassport() {
		return passport;
	}
	public void setPassport(int passport) {
		this.passport = passport;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
}
