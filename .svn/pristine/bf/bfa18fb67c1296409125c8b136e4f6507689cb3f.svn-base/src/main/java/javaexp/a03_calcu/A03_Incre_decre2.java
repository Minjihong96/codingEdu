package javaexp.a03_calcu;

public class A03_Incre_decre2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int no = 1;
		// 1증가 처리
		no = no + 1; // 왼쪽에 있는 연산처리하고 대입(=)해서 오른쪽 데이터를 할당.
		no = no + 1;
		no = no + 1;
		System.out.println("1증가후:"+no);
		no = no + 2;
		System.out.println("2증가후:"+no);
		no = no + 3;
		no = no + 3;
		no = no + 3;
		System.out.println("3증가후:"+no);
		
		// ex) int 변수 count 선언한 후, 초기값 1을 할당하고, 1개씩 증가 2번후 출력
		//	   2개씩 증가 3번 후 출력, 3씩 증가 3번 후 출력
		int count = 1;
		count = count + 1;
		count = count + 1;
		System.out.println("1증가 2번 후 : "+count);
		count = count + 2;
		count = count + 2;
		count = count + 2;
		System.out.println("2증가 3번 후 : "+count);
		count = count + 3;
		count = count + 3;
		count = count + 3;
		System.out.println("3증가 3번 후 : "+count);
		
		// ex) int 변수 tot 선언하고 초기값을 1을 할당 후,
		//     1씩 3번 할당 후 출력, 2씩 2번 할당 후 출력, 3씩 2번 할당 후 출력
		int tot = 1;
		tot = tot + 1;
		tot = tot + 1;
		tot = tot + 1;
		System.out.println("1증가 3번 후 : "+tot);
		tot = tot + 2;
		tot = tot + 2;
		System.out.println("2증가 2번 후 : "+tot);
		tot = tot + 3;
		tot = tot + 3;
		System.out.println("3증가 2번 후 : "+tot);
		
		
		
	}

}
