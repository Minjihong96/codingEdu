package javaexp.a01_begin;

public class A04_Objectstart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("");
		// 기본출력 명령어 : 자바에서는 모든 명령어 마지막에 ;(세미콜론)을 넣어야 한다.
		System.out.println("안녕하세요 객체지향 프로그램 시작합니다.");
        //ex) A05_Objectsecond.java
		//    안녕하세요. 자바 기본출력 완료!!
	}

}
