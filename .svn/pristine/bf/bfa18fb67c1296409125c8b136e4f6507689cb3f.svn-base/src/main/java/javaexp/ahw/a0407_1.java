package javaexp.ahw;

import java.util.Scanner;

public class a0407_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.print("과일명 : ");
			String fruit = sc.nextLine();
			if(fruit.equals("Y")) {
				System.out.println("종료");
				break;
			}
			System.out.println("과일명 : "+fruit);
		}


	}

}
