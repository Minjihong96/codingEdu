package javaexp.a08_object.a03_access;

import javaexp.a08_object.a01classOb.vo.Movie;
import javaexp.a08_object.a02_object.vo.Student;
import javaexp.a08_object.a03_access.vo.Doll;
import javaexp.a08_object.a03_access.vo.Person;
import javaexp.a08_object.a03_access.vo.Pirate;
import javaexp.a08_object.a03_access.vo.TravelPackage;

public class A01_AccessModifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 선언 부터 확인
		// 1. class 앞에 public 붙이면, 다른 패키지라도 import하여
		//		선언 할 수 있지만, public 붙지 않으면, 같은 패키지에서만
		//		접근이 가능하다.
		Pirate p01;
		// 2. 포함 되어있는 생성자의 접근 제어자를 확인해서 public이 아니면
		//		외부에서 호출이 불가능하다.
		p01 = new Pirate();
		// 3. 포함된 속성에 대한 접근도 public이면 접근이 가능하지만,
		//	  그 외는 에러가 발생한다.
		System.out.println("속성접근 : "+p01.treasure);
		// public으로 설정되어 있는 속성 treasure는 다른 패키지 접근 가능
		
		Person pe01 = new Person();
		pe01.setAge(25);
		System.out.println(pe01.getName());
		System.out.println(pe01.getAge());
		System.out.println(pe01.getLoc());
		
		Person pe02 = new Person("홍길동",25,"성남");
		System.out.println(pe02.getName());
		System.out.println(pe02.getAge());
		System.out.println(pe02.getLoc());
		
		Doll d01 = new Doll("토끼인형",15000,true);
		System.out.println(d01.getName());
		System.out.println(d01.getPrice());
		System.out.println(d01.isLimited());
		
		TravelPackage tp01 = new TravelPackage("오사카",3,1600000);
		System.out.println(tp01.getDestination());
		System.out.println(tp01.getDays());
		System.out.println(tp01.getPrice());
		
		Movie m01 = new Movie();
		m01.setTitle("재미있는 영화");
		Movie m02 = new Movie("인셉션","크리스토퍼 놀란",null);
		System.out.println(m01.getTitle());
		System.out.println(m02.getTitle());
		
		Student st1 = new Student();
		st1.setName("김기찬");
		st1.setAge(31);
		st1.setStudentId("dskdnl");
		Student st2 = new Student("이기찬",33,"rlcks7812");
		System.out.println(st1.getName());
		System.out.println(st2.getName());
	}

}
/*
1. class 앞에 public 붙은 경우에는 어디서든지 선언이 가능하다.
2. class 앞에 public이 붙지 않으면 다른 패키지에서는 선언시 에러가 발생
*/
/*
# 접근 제어자
1. 자바의 클래스 멤버(필드.메서드)에 붙이는 접근 제어자 public, protected,
	(default), private 네가지가 있습니다.
	1) public : 누구나 꺼내 쓸 수 있는 멤버입니다. 다른 패키지에서도 마음껏 접근 가능
	2) protected : 같은 패키지 안 또는 상속 관계에 있는 자식 클래스에서만 접근 허용
	3) default(아무런 수식어가 없는 선언) : 같은 패키지 안에서만 접근 가능
		패키지가 다르면 아에 존재가 숨겨집니다.
	4) private : 해당 클래스내부에서만 사용 할 수 있습니다. 아무리 같은 패키지나
		자식클래스라도 외부에서는 보이지 않고, 오직 그 클래스 안에서만 꺼낼 수 있습니다.
2. 위 네가지 클래스 내부 구현을 캐뷸화(encapsulation)이라고 하면,
	외부에서 잘못된 사용을 막고, 안전하게 데이터를 관리합니다.
*/
