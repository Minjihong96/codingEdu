package javaexp.a07_loop;

import java.util.Scanner;

public class A07_while_Scanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("다음 라인에서 데이터(문자열)입력 : ");
		String str1 = sc.nextLine();
		System.out.println("입력된 문자열 : "+str1);
		System.out.print("현재 라인에서 데이터 입력(선택한 번호입력) : ");
		int int1 = Integer.parseInt(sc.nextLine());
		System.out.println("입력한 정수 : "+int1);
		System.out.print("현재 라인에서 데이터 입력(몸무게 소숫점 한자리까지 입력) : ");
		double dbl1 = Double.parseDouble(sc.nextLine());
		System.out.println("입력한 실수 : "+dbl1);
		

	}

}
