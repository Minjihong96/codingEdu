package javaexp.a06_condition;

import java.util.Scanner;

public class A03_if {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// ex) A03_if.java를 만들고, 코인의 갯수를 입력받아서 코인의 갯수가 0 이상일 때,
		//	   각 코인의 갯수마다 10분씩 이용 가능한 시간을 출력하는 프로그램 처리
        //	입력 처리 모듈
		Scanner sc = new Scanner(System.in);
		//  입력 형식
		//  입력할 코인의 갯수
		System.out.print("입력 할 코인의 갯수 : ");
		int coin = sc.nextInt();
		int time = coin*10;
		//  출력 형식
	    //  총 이용 가능한 시간 : @@@ 분   
		if( coin >=0) {
			System.out.println("코인 갯수 : "+coin);
			System.out.println("총 이용 가능한 시간 : "+time+" 분");
		}
		else {
			System.out.println("이용이 불가능 합니다.");
		}
		//  프로그램 종료
		System.out.println("프로그램 종료");

	}

}
