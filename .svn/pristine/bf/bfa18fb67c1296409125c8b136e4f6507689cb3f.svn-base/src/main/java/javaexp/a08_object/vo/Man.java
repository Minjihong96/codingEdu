package javaexp.a08_object.vo;
// 외부에 있는 Man 클래스 선언
public class Man {
	// 멤버(필드)
	// public : 외부 패키지라도 접근이 가능하게 하는 접근제어자
	public String name="홍길동";
	// 생성자
	// 메서드

}
