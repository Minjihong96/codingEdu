package javaexp.a08_object.a04_relation;

import java.util.ArrayList;
import java.util.List;

import javaexp.a08_object.a04_relation.vo.Dept;
import javaexp.a08_object.a04_relation.vo.Person;
import javaexp.a08_object.a04_relation.vo2.Product;

public class A04_CallVo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dept d1 = new Dept(10,"인사","성남"); // 초기화
		System.out.println(d1.getDeptno()); // 가져오기
		System.out.println(d1.getDname());
		System.out.println(d1.getLoc());
		d1.setDname("회계");	// 변경하기
		System.out.println(d1.getDname());
		// Person 	name, age, loc
		Person p1 = new Person("이기찬",35,"성남");
		System.out.println(p1.getName());
		System.out.println(p1.getAge());
		System.out.println(p1.getLoc());
		p1.setLoc("야탑");
		System.out.println(p1.getLoc());
		
		Product pd1 = new Product("사과",1200,4);
		System.out.println("물건 : "+pd1.getName());
		System.out.println("가격 : "+pd1.getPrice());
		System.out.println("갯수 : "+pd1.getCnt());
		/*
		List<객체> 참조변수 = new ArrayList<객체명>();
		참조변수.add(new 객체명(데이터1, 데이터2, 데이터...)); 
		참조변수.add(new 객체명(데이터1, 데이터2, 데이터...)); 
		참조변수.add(new 객체명(데이터1, 데이터2, 데이터...));
		참조변수.get(0) : 할당한 객체중에 첫번째 객체 
		*/
		List<Product> plist = new ArrayList<Product>();
		plist.add(new Product("사과",5000,3));
		plist.add(new Product("바나나",6000,2));
		plist.add(new Product("딸기",15000,4));
		Product pd01 = plist.get(0); // 담긴 객체 중에 첫번쨰 객체를 가져온다.
		System.out.println(pd01.getName());
		System.out.println(pd01.getPrice());
		System.out.println(pd01.getCnt());
		Product pd02 = plist.get(1); // 담긴 객체 중에 첫번쨰 객체를 가져온다.
		System.out.println(pd02.getName());
		System.out.println(pd02.getPrice());
		System.out.println(pd02.getCnt());
		Product pd03 = plist.get(2); // 담긴 객체 중에 첫번쨰 객체를 가져온다.
		System.out.println(pd03.getName());
		System.out.println(pd03.getPrice());
		System.out.println(pd03.getCnt());
		System.out.println("물건명\t가격\t갯수");
		// for(단위데이터 : 배열데이터)
		for(Product pro:plist) {
			System.out.print(pro.getName()+"\t");
			System.out.print(pro.getPrice()+"\t");
			System.out.print(pro.getCnt()+"\n");
		}
		// Dept 객체 
		List<Dept> dlist = new ArrayList<Dept>();
		dlist.add(new Dept(20,"회계","분당"));
		dlist.add(new Dept(30,"인사","성남"));
		dlist.add(new Dept(40,"전산","야탑"));
		System.out.println("부서번호\t부서\t지역");
		for(Dept dep:dlist) {
			System.out.print(dep.getDeptno()+"\t");
			System.out.print(dep.getDname()+"\t");
			System.out.print(dep.getLoc()+"\n");
		}
		

	}

}
