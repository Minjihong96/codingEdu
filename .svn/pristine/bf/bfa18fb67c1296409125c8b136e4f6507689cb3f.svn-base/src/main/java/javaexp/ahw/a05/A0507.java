package javaexp.ahw.a05;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class A0507 {
	
	public static Connection con() {
		
		Connection con = null;
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "scott";
		String pwd = "tige";
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(url,user,pwd);
			System.out.println("접속성공!!");
			
		} catch(ClassNotFoundException e) {
			System.out.println("예외1 : "+e.getMessage());
			
		} catch (SQLException e) {
			System.out.println("예외2 : "+e.getMessage());
			
		}
		
		return con;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			String str[] = new String[5]; // 5개짜리 문자열 배열
			System.out.println(str[5].toString()); // 6번쨰 문자열 배열
		
		}catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("예외 발생시 처리할 내용");
			System.out.println(e.getMessage());
		}
		try {
			String str = null;
			System.out.println("문자열 길이 : " + str.length());
		}catch(NullPointerException e) {
			System.out.println("# 예외 발생 #");
			System.out.println(e.getMessage());
		}
		int totalScore = 80;
		int playerCount = 0;  // 0명이면 평균 계산 불가
		try {
		    int average = totalScore / playerCount;
		    System.out.println("평균 점수: " + average);
		} catch (ArithmeticException e) {
		    System.out.println("플레이어 수가 0이어서 평균을 계산할 수 없습니다.");
		}
		try {
			System.out.println("# 파일 읽기 프로그램 #");
			new FileInputStream("config.txt");
			
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("# 파일 읽기 처리 프로그램 종료 #");
		con();

	}

}
