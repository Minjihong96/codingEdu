package javaexp.starbucks;

import java.util.Scanner;

import javaexp.starbucks.vo.Members;

public class starbucks {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Members m1 = new Members();
		System.out.print("아이디 입력 : ");
		m1.setUsername(sc.nextLine());
		System.out.print("비밀번호 입력 :");
		m1.setPassword(sc.nextLine());
		System.out.println("아이디 : "+m1.getUsername());
		System.out.println("비밀번호 : "+m1.getPassword());
		

	}

}
