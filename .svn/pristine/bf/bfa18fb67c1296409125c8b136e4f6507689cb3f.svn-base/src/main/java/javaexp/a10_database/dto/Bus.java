package javaexp.a10_database.dto;

public class Bus {
	private String busNum;
	private String busPlace;
	public Bus() {
		// TODO Auto-generated constructor stub
	}
	public Bus(String busNum, String busPlace) {
		this.busNum = busNum;
		this.busPlace = busPlace;
	}
	public String getBusNum() {
		return busNum;
	}
	public void setBusNum(String busNum) {
		this.busNum = busNum;
	}
	public String getBusPlace() {
		return busPlace;
	}
	public void setBusPlace(String busPlace) {
		this.busPlace = busPlace;
	}
	
}
