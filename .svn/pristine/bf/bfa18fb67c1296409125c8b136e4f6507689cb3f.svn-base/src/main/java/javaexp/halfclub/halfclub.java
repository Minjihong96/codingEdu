package javaexp.halfclub;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javaexp.a10_database.DB;
import javaexp.halfclub.vo.Product;
//import="javaexp.halfclub.Halfclub" 
public class Halfclub {
	
	public List<Product> getProductList(String productname){
		List<Product> plist = new ArrayList<Product>();
		String sql = "SELECT PRODUCT_SIZE, COLOR, STOCK_QTY FROM PRODUCT WHERE PRODUCT_NAME=?";
		try( Connection con = DB.con();
			 PreparedStatement pstmt = con.prepareStatement(sql); ){
			pstmt.setString(1, productname);
			try(ResultSet rs = pstmt.executeQuery()){
				while(rs.next()) {  // 여러행 
					plist.add(new Product(
							rs.getString("COLOR"), 
							rs.getString("PRODUCT_SIZE"),
							rs.getInt("STOCK_QTY")));
				}
				System.out.println("데이터 로딩 완료:"+plist.size());				
			}
		}catch(SQLException e) {
			System.out.println("DB처리 에러:"+e.getMessage());
		}catch(Exception e) {
			System.out.println("기타 에러:"+e.getMessage());
		}
		return plist;
	}
	
	public int getTotalStock() {
		int totalStock = 0;
        String sql = "SELECT SUM(STOCK_QTY) AS TOTAL_STOCK FROM PRODUCT";
        
        try( Connection con = DB.con();
   			 PreparedStatement pstmt = con.prepareStatement(sql); ){
        	try(ResultSet rs = pstmt.executeQuery()){
				if(rs.next()) {  
					totalStock = rs.getInt("TOTAL_STOCK");
				}
				System.out.println("데이터 로딩 완료:");				
			}
		}catch(SQLException e) {
			System.out.println("DB처리 에러:"+e.getMessage());
		}catch(Exception e) {
			System.out.println("기타 에러:"+e.getMessage());
		}
   		return totalStock;
	}
	

	public Product getProduct(int productId){
		Product p = null;
		String sql = "SELECT PRODUCT_NAME, PRICE, BRAND FROM PRODUCT WHERE PRODUCT_ID = ?";
		try( Connection con = DB.con();
			 PreparedStatement pstmt = con.prepareStatement(sql);
			){
			pstmt.setInt(1, productId);
			try( ResultSet rs = pstmt.executeQuery() ){
				if(rs.next()) { 
					p = new Product(
							rs.getString("PRODUCT_NAME"),
							rs.getInt("PRICE"),
							rs.getString("BRAND"));
				}
			}
			System.out.println("데이터 상세 완료");
		}catch(SQLException e) {
			System.out.println("DB처리 에러:"+e.getMessage());
		}catch(Exception e) {
			System.out.println("기타 에러:"+e.getMessage());
		}
		return p;
	} 
 


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Halfclub dao = new Halfclub();
		for(Product hf:dao.getProductList("반팔 캐주얼셔츠")) {
			System.out.print(hf.getColor()+"\t");
			System.out.print(hf.getProductSize()+"\t");
			System.out.print(hf.getStockQty()+"\n");
		}
		Product p = dao.getProduct(1001);
		System.out.println("#상세 : "+p.getProductName());
		System.out.println("#상세 : "+p.getBrand());
		System.out.println("#상세 : "+p.getPrice());

	}

}
