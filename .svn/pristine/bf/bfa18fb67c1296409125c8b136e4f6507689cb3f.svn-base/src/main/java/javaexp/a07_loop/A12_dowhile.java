package javaexp.a07_loop;

public class A12_dowhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 #do while 구문
		 1. while 구문은 반복조건이 있을 때만, 반복 처리하지만,
		 	do while 구문은 반복조건을 마지막에 check해서,
		 	일단, **한번은 해당 반복 블럭 구문을 수행할 때 사용된다.**
		 2. 기본형식
		 	do{
		 		계속 수행할 반복 내용
		 	}while(조건);	
		 */
		int cnt = 1;
		do {
			System.out.println("카운트 : "+(cnt++));
		}while(cnt<=10);
		System.out.println("반복문 종료");
		/*
		 ex) int count로 100을 설정 후, do while로 90까지 출력
		 */
		int count = 100;
		do {
			System.out.println("카운트 : "+(count--));
		}while(count>=90);
		System.out.println("반복문 종료");

	}

}
