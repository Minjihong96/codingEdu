package javaexp.a08_object;

import javaexp.a08_object.vo.PizzaOrder;

public class A0423 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PizzaOrder po = new PizzaOrder("홍길동","페퍼로니","Large",true);
		System.out.println(po.getCustomerName());
		System.out.println(po.getPizzaType());
		System.out.println(po.getSize());
		System.out.println(po.isExtraCheese());
		

	}

}
