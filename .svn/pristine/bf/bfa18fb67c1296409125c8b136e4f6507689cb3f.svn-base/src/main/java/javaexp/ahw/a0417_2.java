package javaexp.ahw;

public class a0417_2 {

	public static void main(String[] args) {
		Movie1 m1 = new Movie1("기생충","봉준호");
		m1.showmov();
		Reservation re = new Reservation("이기찬", "야간","h열 2번");
		re.showRE();

	}

}
class Movie1{
	String title;
	String actor;
	public Movie1(String title, String actor) {
		this.title = title;
		this.actor = actor;
	}
	void showmov() {
		System.out.println("영화 제목 : "+title);
		System.out.println("감독 : "+actor);
	}
	
}
class Reservation{
	String name;
	String time;
	String set;
	public Reservation(String name, String time, String set) {
		this.name = name;
		this.time = time;
		this.set = set;
	}
	void showRE() {
		System.out.println("예약자 이름 : "+name);
		System.out.println("시간 : "+time);
		System.out.println("좌석 : "+set);
	}
}