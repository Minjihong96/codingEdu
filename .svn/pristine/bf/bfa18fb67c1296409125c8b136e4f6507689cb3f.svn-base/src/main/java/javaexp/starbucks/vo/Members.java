package javaexp.starbucks.vo;

import java.time.LocalDateTime;
import java.util.Date;

public class Members {
	private Long memberId;
    private String username;           // ID
    private String password;           // 암호화 저장 전제
    private String name;
    private String gender;             // 'male' or 'female'
    private Date birthDate;            // 생년월일 (yyyy-MM-dd)
    private String calendarType;       // 'solar' or 'lunar'
    private String phone;
    private String email;
    private String nickname;
    private String agreeSms;           // 'Y' or 'N'
    private String agreeEmail;         // 'Y' or 'N'
    private String agreeOptionalTerms; // 'Y' or 'N'
    private LocalDateTime createdAt;
	public Members() {
		// TODO Auto-generated constructor stub
	}
	public Members(Long memberId, String username, String password, String name, String gender, Date birthDate,
			String calendarType, String phone, String email, String nickname, String agreeSms, String agreeEmail,
			String agreeOptionalTerms, LocalDateTime createdAt) {
		this.memberId = memberId;
		this.username = username;
		this.password = password;
		this.name = name;
		this.gender = gender;
		this.birthDate = birthDate;
		this.calendarType = calendarType;
		this.phone = phone;
		this.email = email;
		this.nickname = nickname;
		this.agreeSms = agreeSms;
		this.agreeEmail = agreeEmail;
		this.agreeOptionalTerms = agreeOptionalTerms;
		this.createdAt = createdAt;
	}
	public Long getMemberId() {
		return memberId;
	}
	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	public String getCalendarType() {
		return calendarType;
	}
	public void setCalendarType(String calendarType) {
		this.calendarType = calendarType;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getAgreeSms() {
		return agreeSms;
	}
	public void setAgreeSms(String agreeSms) {
		this.agreeSms = agreeSms;
	}
	public String getAgreeEmail() {
		return agreeEmail;
	}
	public void setAgreeEmail(String agreeEmail) {
		this.agreeEmail = agreeEmail;
	}
	public String getAgreeOptionalTerms() {
		return agreeOptionalTerms;
	}
	public void setAgreeOptionalTerms(String agreeOptionalTerms) {
		this.agreeOptionalTerms = agreeOptionalTerms;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
    
}
