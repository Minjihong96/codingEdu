package javaexp.ahw.a05.Vo;

import java.util.Date;

public class Car {

	private String make;
	private String model;
	private Date year;
	public Car() {
		// TODO Auto-generated constructor stub
	}
	public Car(String make, String model, Date year) {
		this.make = make;
		this.model = model;
		this.year = year;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Date getYear() {
		return year;
	}
	public void setYear(Date year) {
		this.year = year;
	}
	
}
