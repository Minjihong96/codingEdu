package javaexp.a08_object.a04_relation;

public class A01_2_OneAndOneReview {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		License li01 = new License("G20250101");// 객체를 생성하고 필드값을 초기화 처리
		CarOwner co01 = new CarOwner("이기찬",li01);

		co01.showlicense();
		System.out.println("이름 : "+co01.getName());
		Subject sb01 = new Subject(80,90,100);
		System.out.println(sb01);
		sb01.setEng(75);
		System.out.println(sb01.getEng());
		System.out.println(sb01.getKor());
		System.out.println(sb01.getMath());
	}

}
class Subject{
	private int kor;
	private int eng;
	private int math;
	
	public Subject(int kor, int eng, int math) {
		this.kor = kor;
		this.eng = eng;
		this.math = math;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	
}
// 차소유주와 운전면허
class License{
	// 접근제어자를 private를 만들어 직접 접근이 불가능하게 처리
	private String licenseNumber;

	public License() {
	}
	//생성자를 통해서 필드값을 초기화 처리
	public License(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}
	// private로 설정된 필드를 읽기 위한 get메서드로 설정
	public String getLicenseNumber() {
		return licenseNumber;
	}
	// private로 설정된 필드를 쓰기 위한 set메서드로 설정
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}
	
}
class CarOwner{
	private String name;
	private License license;
	
	public CarOwner(String name, License license) {
		this.name = name;
		this.license = license;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public License getLicense() {
		return license;
	}
	public void setLicense(License license) {
		this.license = license;
	}
	public void showlicense() {
		System.out.println("여권 번호 : "+license.getLicenseNumber());
	}
}