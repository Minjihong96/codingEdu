package javaexp.a08_object.a04_relation;

public class A01_OneAndOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 목줄 생성
		Leash myLeash = new Leash("빨간색");
		// 강아지 객체(목줄 연결)
		Dog myDog = new Dog("초코",myLeash);
		myDog.goWalk();
		// 강아지 2객체 생성(푸아숑, 노랑색 목줄로 할당 처리)
		Leash myLeash2 = new Leash("노랑색");
		Dog myDog2 = new Dog("푸아숑",myLeash2);
		myDog2.goWalk();
		
		Toy myToy = new Toy("처키");
		Child ch = new Child("홍길동",myToy);
		ch.Play();
		Toy t2 = new Toy("에나벨");
		Child ch2 = new Child("김길동",t2);
		ch2.Play();
		
		Bag b1 = new Bag("란도셀");
		Student st = new Student("신길동",b1);
		st.gotoSchool();

	}

}
/*
# java에서 1:1관계
1. 하나의 객체가 다른 하나의 객체와 단 하나씩 짝을 이루는 관계를 의미합니다.
 	예를들어, 한 사람은 하나의 여권을 가지고 있고, 한 여권도 한 사람에게만 속하는 구조가
 	바로 1:1 관계입니다.
 2. 자바에서는 1:1 관계를 설정할 때
 	1) 한 클래스 안에 다른 클래스 타입의 필드(멤버변수)를 선언하고 표현합니다.
 	2) 객체를 생성할 때, 두객체가 서로 연결되어야 의미 있는 구조가 됩니다.
 3. 1:1관계 설정 방법
 	1) 1단계 : 클래스 A, 클래스 B를 각각 정의한다.
 	2) 2단계 : 클래스 A안에 클래스 B 타입의 필드를 선언한다
 	3) 3단계 : 객체 생성 시, 클래스 A의 필드에 클래스 B의 객체를 주입(참조 연결)한다.
 	4) 4단계 : 필요 시 두객체의 데이터에 접근하거나 조작한다.
*/
// 목줄
class Leash{
	String color;

	public Leash(String color) {
		this.color = color;
	}
	
	public void showLeash() {
		System.out.println("목줄 색상 : "+color);
	}
}
class Dog{
	String name;
	Leash leash; // 1:1관계로 객체안에 객체를 설정 처리
	public Dog(String name, Leash leash) {
		this.name = name;
		this.leash = leash;
	}
	public void goWalk() {
		System.out.println(name+"가 산책을 갑니다.");
		leash.showLeash();
	}
	
}
/*
# 장난감(Toy-장난감이름), showToy() 장난감 이름 출력 
  장난감을 가진(child-chiName, Toy)
  	play() @@가 장난감을 가지고 놀아요
  		   장난감 이름은 @@@ 입니다.
*/
class Toy{
	String toy;

	public Toy(String toy) {
		this.toy = toy;
	}
	public void showToy() {
		System.out.println("장난감 이름은 "+toy+" 입니다.");
	}
}
class Child{
	String child;
	Toy toy;
	public Child(String child, Toy toy) {
		this.child = child;
		this.toy = toy;
	}
	public void Play() {
		System.out.println(child+"가 장난감을 가지고 놀아요");
		toy.showToy();
	}
}
/*
# Bag(brand) showBag() 책가방 브랜드 @@@ Student(name, Bag) gotoSchool() : @@가 학교에 갑니다.
*/
class Bag{
	private String brand;

	public Bag(String brand) {
		this.brand = brand;
	}
	public void showBag() {
		System.out.println("책가방 브랜드 : "+brand);
	}
}
class Student{
	private String name;
	private Bag bag;
	public Student(String name, Bag bag) {
		this.name = name;
		this.bag = bag;
	}
	public void gotoSchool() {
		System.out.println(name+"가 학교에 갑니다.");
		bag.showBag();
	}
}
