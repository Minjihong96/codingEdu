package javaexp.ahw;

public class a0331 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 1. **📘 마법학교 출석부 만들기**  
   			- 학생들의 학점를 배열로 저장하고, 각 학점에 해당하는 점수('A','B','C','D')을 출력하세요. (예: `students[0] = 'A'`)
		 */
		char grade[]= {'A','B','C','D'};
		System.out.println(grade[0]);
		System.out.println(grade[1]);
		System.out.println(grade[2]);
		System.out.println(grade[3]);
		
		int student[]= {80,70,75,95,100};
		System.out.println("학생 1 : "+student[0]);
		System.out.println("학생 2 : "+student[1]);
		System.out.println("학생 3 : "+student[2]);
		System.out.println("학생 4 : "+student[3]);
		System.out.println("학생 5 : "+student[4]);


	}

}
