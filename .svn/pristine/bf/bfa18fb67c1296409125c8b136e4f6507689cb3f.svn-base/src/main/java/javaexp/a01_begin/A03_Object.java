package javaexp.a01_begin;

public class A03_Object {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        /*
        javaexp.a01_begib.A03_Object.java: 사람이 만든 코드         
        javac.exe A03_Object.java : 컴파일과정 수행.
        A03_Object.clss : 기계어가 만들어짐 (컴퓨터가 인식할 수 있는 코드)
        java.exe A03_Object : 수행 처리(main()메서드가 있는 파일)
        */
		// sysout + ctrl + space
		System.out.println("최종 결과 수행(출력)");
		
		//A04_Objectstart.java
		//안녕하세요 객체지햐ㅏㅇ 프로그램 시작합니다. 출력되게 처리하세요.
	}

}
