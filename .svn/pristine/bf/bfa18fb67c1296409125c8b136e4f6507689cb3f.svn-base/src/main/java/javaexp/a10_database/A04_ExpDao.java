package javaexp.a10_database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javaexp.a10_database.dto.Dept;
import javaexp.a10_database.dto.Emp;

public class A04_ExpDao {
	
	public int getCountEmp(int deptno){
		int count=0;
		String sql = "SELECT COUNT(*) CNT FROM EMP WHERE DEPTNO=?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setInt(1, deptno); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					if(rs.next()) {   // 한개 행 리턴
						count=rs.getInt("CNT"); 
						// 컬럼과 데이터 유형에 따라 rs.get데이터유형("컬럼명");
						// 리턴할 결과값 count에 할당처리
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return count;
	}
	
	public double getSalbyEmpno(int empno){
		double sal = 0;
		String sql = "SELECT SAL FROM EMP WHERE EMPNO = ?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setInt(1, empno); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					if(rs.next()) {   // 한개 행 리턴
						sal=rs.getDouble("SAL"); 
						// 컬럼과 데이터 유형에 따라 rs.get데이터유형("컬럼명");
						// 리턴할 결과값 sal에 할당처리
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return sal;
	}
	
	public int getEmpnobyEname(String ename){
		int empno = 0;
		String sql = "SELECT EMPNO FROM EMP WHERE ENAME = ?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setString(1, ename); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					if(rs.next()) {   // 한개 행 리턴
						empno=rs.getInt("EMPNO");
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return empno;
	}
	
	public String getJobbySal(double sal){
		String job = "";
		String sql = "SELECT JOB FROM EMP WHERE SAL = ?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setDouble(1, sal); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					if(rs.next()) {   // 한개 행 리턴
						job=rs.getString("JOB");
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return job;
	}
	
	public List<String> getEnamesByDeptno(int deptno){
		List<String> enames = new ArrayList<String>();
		String sql = "SELECT ENAME FROM EMP WHERE DEPTNO = ?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setInt(1, deptno); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					while(rs.next()) {   // 한개 행 리턴
						enames.add(rs.getString("ENAME"));
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		return enames;
	}
	
	public List<String> getEnamesbyJob(String job){
		List<String> enames = new ArrayList<String>();
		String sql = "SELECT ENAME FROM EMP WHERE JOB = ?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setString(1, job); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					while(rs.next()) {   // 한개 행 리턴
						enames.add(rs.getString("ENAME"));
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		return enames;
	} 
	
	public List<Integer> getEmpnosbyMgr(int mgr){
		List<Integer> empnos = new ArrayList<Integer>();
		String sql = "SELECT EMPNO FROM EMP WHERE MGR = ?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setInt(1, mgr); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					while(rs.next()) {   // 한개 행 리턴
						empnos.add(rs.getInt("EMPNO"));
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		return empnos;
	}
	public List<Double> getSalsbyDeptno(int deptno){
		List<Double> sals = new ArrayList<Double>();
		String sql = "SELECT SAL FROM EMP WHERE DEPTNO = ?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setInt(1, deptno); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					while(rs.next()) {   // 한개 행 리턴
						sals.add(rs.getDouble("SAL"));
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		return sals;
	}
	
	public List<Emp> getSalEname(Emp sch){
		List<Emp> list = new ArrayList<Emp>();
		String sql = "SELECT SAL, ENAME FROM EMP WHERE DEPTNO = ? OR JOB = ?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){	
			    pstmt.setInt(1, sch.getDeptno());
				pstmt.setString(2, sch.getJob());
				try(ResultSet rs = pstmt.executeQuery()){
					while(rs.next()) {   // 한개 행 리턴
						list.add(new Emp(rs.getString("ENAME"), rs.getDouble("SAL") ));
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		return list;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A04_ExpDao dao = new A04_ExpDao();
		for(String ename:dao.getEnamesByDeptno(10)) {
			System.out.println(ename);
		}
		for(String ename:dao.getEnamesbyJob("CLERK")) {
			System.out.println(ename);
		}
		for(int empno:dao.getEmpnosbyMgr(7698)) {
			System.out.println(empno);
		}
		for(double sal:dao.getSalsbyDeptno(10)) {
			System.out.println(sal);
		}
		Emp sch = new Emp();         // 검색 조건용 Emp 객체 생성
		sch.setDeptno(10);
		sch.setJob("CLERK");
		
		for(Emp da:dao.getSalEname(sch)) {
			
			System.out.print(da.getSal()+"\t");
			System.out.println(da.getEname());
		}
		System.out.println(dao.getSalbyEmpno(7369));
		System.out.println(dao.getCountEmp(10));
		System.out.println(dao.getEmpnobyEname("ALLEN"));
		System.out.println(dao.getJobbySal(2975));
		
	}

}
