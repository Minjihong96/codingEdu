package javaexp.a08_object;

import java.util.Scanner;

public class A06_FunctionParam {
	// 매개벼누 1개 처리
	static void call1(int no) {
		System.out.println("부른 번호는 "+no);
	}
	static void buy() {
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.print("구매한 물건(Y는 종료) : ");
			String name = sc.nextLine();
			if(name.equals("Y")) {
				System.out.println("종료");
				break;
			}
			System.out.print("가격 : ");
			int price = Integer.parseInt(sc.nextLine());
			System.out.println(name+"을 "+price+"원에 구매하였습니다.");
		}
		
		
	}
	// 매개변수 2개이상 처리하는 함수 선언
	static void showScore(String name, int point) {
		System.out.println("학생의 이름은 "+name+"이고, 획득한 점수는 "+point+"점이다.");
	}
	static void buyProd(String product, int price, int cnt) {
		System.out.println("구매한 물건은 "+product+"이고, 가격은 "+price+"원, 갯수는 "+cnt+"개 입니다.");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		showScore("홍길동",85);  // 선언된 타입과 순서, 갯수에 맞게 전달하여야 한다.
		buyProd("지갑",250000,2);
		call1(25);  // 선언된 데이터 유형에 맞게 매개변수로 데이터를 전달
		buy();
		

	}

}
