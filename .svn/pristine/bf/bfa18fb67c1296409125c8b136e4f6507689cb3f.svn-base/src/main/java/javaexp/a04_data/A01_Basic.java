package javaexp.a04_data;

public class A01_Basic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 # 자바의 데이터 유형
		 1. 기본데이터 유형
		 	1) 메모리를 stack영역 하나만 사용/한정된 데이터를 저장
		 	2) 정수형 데이터
		 		byte(8bit) : -128~127
		 		short(2바이트) : -32768~32767
		 		int(4바이트) : -2147483648~2147483647(약 21억)
		 		long(8바이트) : 구경정도 범위(경조억...)
		 			long data01 = 3147483647L; 21억이상의 정수형 할당시는 L/l를 붙여서 사용하여야 한다.
		 		- 주로 int형을 사용
		 	
		 	3) 실수형 데이터
		 		float(4바이트)
		 			float data02 = 3.14F; float도 사용시 F/f를 붙여서 사용하여야 한다.
		 		double(8바이트)
		 			double data3 = 3.14;
		 		- 주로 double형을 사용
		 		
		 	4) 문자형 데이터
		 		char(2바이트) : 0~65535(유니코드문자로 1문자 표현)
		 		
		 	5) boolean 데이터
		 		1비트 : 0/1 true/false 실제메모리는 java(자바가상머신)에 따라 다름
		 	
		 	
		 2. 객체형데이터 유형
		 	1) 메모리를 stack영역과 heap영역 두개를 사용
		 	2) 배열
		 	3) String
		 	4) 사용자 정의 class 객체
		 	
		 	
		 # 자바에서 데이터 비교
		 
		 # 자바에서 입력 처리
		 
		 */
		int intMax = 2147483647;
		long longData = 3147483647L;
		System.out.println("정수형(int)"+intMax);
		System.out.println("정수형(longData)"+longData);
		float floatData = 3.14F; // 소숫점 6~7자리까지 처리
		double dblData = 3.14; // 소숫점 15자리까지 처리
		System.out.println("실수형(float)"+floatData);
		System.out.println("실수형(dblData)"+dblData);
		
		/*
		 위 데잍 중에 long 데이터를 이용해서, 우주여행을 떠날려면 우주선의 연료와 여러 비용을
		 계산합니다. fuelCost로 우주선의 연료 비용을 150억 할당, 승무원 급여는 10억 할당하여
		 총우주여행 비용 totalCost를 출력
		 */
		long fuelCost = 15000000000L;
		int hmCost = 1000000000;
		long totalCost = fuelCost+hmCost;
		System.out.println("총 우주여행 비용 : "+totalCost);
		
		/*
		 ex) long, double를 활용하여 지구와 달간의 평균 거리를 distanceToMoon(384400000)로
		 	미터단위로 할당하고, 이것을 키로미터단위로 distanceInKm로 할당하세요.
		 */
		long distanceMoon = 384400000L;
		double distanceInKm = 1000.0;
		System.out.println("지구와 달간의 평균 거리 : "+(distanceMoon/distanceInKm)+"km");
		
		/*
		 ex) 기차가 시속 100킬로미터로 이동할 때, 450킬로미터 거리를 이동하는데 걸리는 시간을 계산하세요.
		 속도(speed), 여행거리(distance), 걸리는 시간(timeInHours), 걸리는 분(timeInminute)
		 걸리는 시간 = 여행거리/속도
		 걸리는 분 = 걸리는 시간*60
		 */
		double speed =100;
		long distance =450;
		double timeInHours = distance/speed;
		double timeInminute = timeInHours*60;
		System.out.println("속도 : "+speed);
		System.out.println("걸리는 시간 : "+timeInHours+"시간");
		System.out.println("걸리는 분 : "+timeInminute+"분");
		
	}

}
