package javaexp.halfclub.vo;
// javaexp.halfclub.vo.Product
public class Product {
	/*
	PRODUCT_ID      NUMBER PRIMARY KEY,          -- 상품 고유 ID
    PRODUCT_NAME    VARCHAR2(200) NOT NULL,      -- 상품 이름
    BRAND           VARCHAR2(100),               -- 브랜드 이름
    COLOR           VARCHAR2(50),                -- 색상
    PRODUCT_SIZE    VARCHAR2(20),                -- 사이즈
    STOCK_QTY       NUMBER DEFAULT 0    		 -- 재고 수량
    PRICE 			NUMBER DEFAULT 0             -- 가격
	*/
	private int productId;
	private String productName;
	private String brand;
	private String color;
	private String productSize;
	private int stockQty;
	private int price;
	public Product() {
		// TODO Auto-generated constructor stub
	}
	public Product(int productId, String productName, String brand, String color, String productSize, int stockQty,
			int price) {
		this.productId = productId;
		this.productName = productName;
		this.brand = brand;
		this.color = color;
		this.productSize = productSize;
		this.stockQty = stockQty;
		this.price = price;
	}
	
	public Product(String color, String productSize, int stockQty) {
		this.color = color;
		this.productSize = productSize;
		this.stockQty = stockQty;
	}
	
	
	public Product(String productName, int price, String brand) {
		this.productName = productName;
		this.brand = brand;
		this.price = price;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getProductSize() {
		return productSize;
	}
	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}
	public int getStockQty() {
		return stockQty;
	}
	public void setStockQty(int stockQty) {
		this.stockQty = stockQty;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
}
