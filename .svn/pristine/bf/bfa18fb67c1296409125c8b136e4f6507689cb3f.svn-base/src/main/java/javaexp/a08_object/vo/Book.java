package javaexp.a08_object.vo;

public class Book {
	public int curPage; // int형 기본적으로 0이 할당된다.(클래스/객체 경우)
}
