package javaexp.a05_util;

public class A01_Random {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 # 임의의(random) 수 만들기
		 1. 대부분의 프로그램에서 임의의 수를 만들어 프로그램을 처리하는 경우가 많다.
		 	예를 들어 주사위 굴리기, 0~100사이에 임의의 점수나오게 하기,
		 	가위/바위/보 중에 임의로 나오게 하기, 짝/홀 중에 임의로 나오게 하기 등.
		 2. 이런 임의의 수를 자바에서는 다음의 형식과 단계에 의해서 만들고 있다.
		 3. 기본 형식
		 	1) 0.0 <= Math.random() < 1.0
		 		Math.random()은 실수 0.0보다 같거나 크고, 실수 1.0보다 작은 범위에서 임의의 수가 나오게 한다.
		 	2) 1~10까지 임의의 정수를 나오게 하려면 
		 		경우의 수 : 10
		 		
		 		0.0 <= Math.random() < 1.0
		 		0.0*10 <= Math.random()*10 <1.0*10
		 		0.0 <= Math.random()*10 < 10.0
		 		0 <= (int)(Math.random()*10) < 10
		 			0,1,2,...,9 ==>1,2,....,10
		 		0+1 <= (int)(Math.random()*10+1) < 10+1
		 		1 <= (int)(Math.random()*10+1) < 11
		 		경우의 수와, 시작수를 가져오면 정수로 임의의 수를 도출 할 수 있다.
		 		(int)(Math.random()*경우의 수 + 시작 수)
		 	3) 검증1) 주사위 돌리기
		 		경우의 수 : 6가지
		 		시작의 수 : 1
		 		1,2,3,4,5,6
		 		1 <=(int)(Math.random()*6 + 1)< 7
		 	
		 */
		System.out.println(Math.random());
		System.out.println(Math.random()*10);
		System.out.println((int)(Math.random()*10));
		System.out.println((int)(Math.random()*10+1));
		System.out.println("주사위 돌리기 : ");
		System.out.println((int)(Math.random()*6+1));
		
		double ran = Math.random();
		System.out.println(ran);
		System.out.println(ran*10);
		System.out.println((int)(ran*10));
		System.out.println((int)(ran*10+1)); // 1<= ran <11 이지만 정수형으로 케스팅해서 1~10까지 정수만 랜덤으로 나온다.
		System.out.println("주사위 돌리기 : ");
		System.out.println((int)(ran*6+1));
		System.out.println("1,2만 임의로 나오는 수");
		System.out.println((int)(ran*2+1));
		// (int)(Math.random()*경우의 수 + 시작 수)
		// ex) 가위 바위 보를 하기 위해서 0, 1, 2까지 임의로 나오게 하였다 위 임의의 수를 처리
		System.out.println((int)(ran*3));
		// ex) 홀짝을 하기 위해서 0, 1로 임의로 나오게 하였다 임의의 수를 처리
		System.out.println("홀짝 0, 1");
		System.out.println((int)(ran*2));
		System.out.println((int)(ran*2) == 0?"짝":"홀");
		// ex) 모두의 마블 주사위(2~12)임의의 수를 나오게 하세요
		System.out.println("모두의 마블 주사위 2개 던질 때");
		System.out.println((int)(ran*6+1)+(int)(ran*6+1));
		System.out.println((int)(ran*11+2)); // 주사위 2개 랜덤 돌린 것과 한번에 던진 거는 나오는 수의 차이가 나올 수도 있다.
		
		String games[] = {"가위","바위","보"};
		System.out.println(games[0]);
		System.out.println(games[1]);
		System.out.println(games[2]);
		
		int rIdx = (int)(ran*3);
		System.out.println("임의로 나온 가위 바위 보 : "+games[rIdx]);

	}

}
