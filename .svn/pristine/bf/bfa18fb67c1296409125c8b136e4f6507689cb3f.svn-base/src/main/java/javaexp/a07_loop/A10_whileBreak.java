package javaexp.a07_loop;

import java.util.Scanner;

public class A10_whileBreak {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.print("회원명 입력(종료시Y) : ");
			String memName= sc.nextLine();
			if(memName.equals("Y")) {
				System.out.println("입력종료");
				break;
			}
			System.out.println("입력된 회원명 : "+memName);
		}

	}

}
