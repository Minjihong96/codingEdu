package javaexp.a02_var;

public class a0320 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	       int apple = 6000;
	       int banna = 5000;
	       int straw = 4000;
	       int a = 3;
	       int b = 6;
	       int c = 5;
	       int price;
	       price = apple*a+banna*b+straw*c;
	       System.out.println("총 가격 : "+price);

	}

}
