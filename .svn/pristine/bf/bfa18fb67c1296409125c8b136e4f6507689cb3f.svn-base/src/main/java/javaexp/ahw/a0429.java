package javaexp.ahw;

public class a0429 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Weapon wp = new Weapon("궁그닐", 1000);
		Hero hr = new Hero("홍길동");
		hr.setWeapon(wp);
		hr.attack();
		
		Collar collar = new Collar("빨강", true);
        Cat1 cat = new Cat1("빨강이", collar);
        cat.meow();
        
        Book2 book = new Book2("자바", "홍길동");
        Member member = new Member("이기찬");
        member.borrowBook(book);
        Ticket ticket = new Ticket("Korean Air", "15B");
        Passenger passenger = new Passenger("이기찬", ticket);
        passenger.checkIn();
        
        Phone phone = new Phone("Galaxy S25", 1200000);
        Customer customer = new Customer("이기찬");
        customer.buyPhone(phone);
	}

}
//Phone 클래스
class Phone {
 private String modelName;
 private int price;

 public Phone(String modelName, int price) {
     this.modelName = modelName;
     this.price = price;
 }

 public String getInfo() {
     return "모델명: " + modelName + ", 가격: " + price + "원";
 }
}

//Customer 클래스
class Customer {
 private String name;
 private Phone purchasedPhone;

 public Customer(String name) {
     this.name = name;
 }

 public void buyPhone(Phone phone) {
     this.purchasedPhone = phone;
     System.out.println(name + " 고객님이 핸드폰을 구매하셨습니다.");
     System.out.println("구매한 핸드폰 정보 → " + phone.getInfo());
 }
}

class Ticket {
    private String airline;
    private String seatNumber;

    public Ticket(String airline, String seatNumber) {
        this.airline = airline;
        this.seatNumber = seatNumber;
    }

    public String getInfo() {
        return "항공사: " + airline + ", 좌석번호: " + seatNumber;
    }
}

// Passenger 클래스
class Passenger {
    private String name;
    private Ticket ticket;

    public Passenger(String name, Ticket ticket) {
        this.name = name;
        this.ticket = ticket;
    }

    public void checkIn() {
        System.out.println(name + "님 탑승 수속 완료.");
        System.out.println("티켓 정보 → " + ticket.getInfo());
    }
}
//Book 클래스
class Book2 {
 private String title;
 private String aut;

 public Book2(String title, String aut) {
     this.title = title;
     this.aut = aut;
 }

 // 책 정보 반환
 public String getInfo() {
     return "제목: " + title + ", 저자: " + aut;
 }
}

//Member 클래스
class Member {
 private String name;
 private Book2 borrowedBook;

 public Member(String name) {
     this.name = name;
 }

 // 책 대여
 public void borrowBook(Book2 book) {
     this.borrowedBook = book;
     System.out.println(name + "님이 책을 대여하였습니다.");
     System.out.println("대여한 책 정보 → " + book.getInfo());
 }
}

class Collar {
    private String color;
    private boolean hasBell;

    public Collar(String color, boolean hasBell) {
        this.color = color;
        this.hasBell = hasBell;
    }

    public String getColor() {
        return color;
    }

    public boolean hasBell() {
        return hasBell;
    }

    public String toString() {
        return "색상: " + color + ", " + (hasBell ? "방울 있음" : "방울 없음");
    }
}

// 고양이 클래스
class Cat1 {
    private String name;
    private Collar collar;

    public Cat1(String name, Collar collar) {
        this.name = name;
        this.collar = collar;
    }

    public void meow() {
        System.out.println(name + "가 '야옹~' 하고 울어요!");
        System.out.println("목걸이 정보 → " + collar);
    }
}

/*
### 🎯 실습문제 2
**"고양이 호텔 시스템"**  
- `Collar` 클래스(속성: 색상, 방울유무)를 만들고,  
- `Cat` 클래스는 `Collar` 객체를 포함하여 등록되어야 합니다.  
- 고양이가 울 때 목걸이 정보를 함께 출력하는 `meow()` 메서드를 만들어보세요.

---

### 🎯 실습문제 3
**"책 대여 시스템"**  
- `Book` 클래스(속성: 제목, 저자)를 만들고,  
- `Member` 클래스(속성: 회원명, 대여한 Book)를 만들어서,  
- 대여한 책의 정보를 함께 출력하는 `borrowBook()` 메서드를 구현하세요.

---

### 🎯 실습문제 4
**"비행기 탑승 프로젝트"**  
- `Ticket` 클래스(속성: 항공사, 좌석번호)를 만들고,  
- `Passenger` 클래스는 하나의 `Ticket`을 가지고 있습니다.  
- `checkIn()` 메서드를 만들어 탑승 수속 정보를 출력하세요.

---

### 🎯 실습문제 5
**"핸드폰 가게 시스템"**  
- `Phone` 클래스(속성: 모델명, 가격)를 만들고,  
- `Customer` 클래스(속성: 이름, 구매한 Phone)를 만들어  
- `buyPhone()` 메서드로 고객이 구매한 핸드폰 정보를 출력하세요.

*/
class Weapon{
	private String wpName;
	private int attack;
	public Weapon(String wpName, int attack) {
		this.wpName = wpName;
		this.attack = attack;
	}
	
	public String getWpName() {
		return wpName;
	}

	public int getAttack() {
		return attack;
	}

	public void showwp() {
		System.out.println("무기이름 : "+wpName);
		System.out.println("공격력 : "+attack);
	}
}
class Hero{
	private String name;
	private Weapon weapon;
	public Hero(String name) {
		this.name = name;
	}
	public void setWeapon(Weapon weapon1) {
		this.weapon = weapon1;
		System.out.println("무기 "+weapon1.getWpName()+"가 장착되었습니다");
	}
	public void showHe() {
		System.out.println("영웅이름 : "+name);
		weapon.showwp();
	}
	public void attack() {
		if(weapon != null) {
			System.out.println(name+"가 "+weapon.getWpName()+"으로 "+weapon.getAttack()+"데미지 공격을 합니다.");
		}else {
			System.out.println(name+"가 맨손으로 공격을 합니다.");
		}
		
	}
}