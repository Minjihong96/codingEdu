package javaexp.ahw;

import java.util.Scanner;

public class a04010_2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.print("사격 점수(0점 시 종료) : ");
			int score = Integer.parseInt(sc.nextLine());
			if(score==0) {
				System.out.println(score+"점 입니다. 종료");
				break;
			}
			System.out.println(score+"점 입니다!");
		}

	}

}
