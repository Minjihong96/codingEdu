package javaexp.a08_object;

public class A07_Function_Ret {
	
	// 함수를 호출할 때, void 리턴값이 없을 때, 출력만하거나, 저장하거나 할때, 사용
	// 리턴값이 있는 것을 실제 이 함수를 데이터를 전달해준다.
	static void ret1() {
		System.out.println("함수의 리턴값이 없음!");
	}
	/*
	 리턴유형 함수명(){
	 	return 실제넘기는 데이터;
	 }
	 */
	static int ret2() {
		System.out.println("정수를 리턴하는 함수");
		return 25;
	}
	// 변수로 리턴 처리
	static int ret3() {
		System.out.println("변수를 통한 리턴");
		int no = 30;
		return no;
	}
	static String ret4() {
		System.out.println("문자열 리턴하는 함수");
		String name = "홍길동";
		return name;
	}
	static double ret5() {
		System.out.println("변경되는 random 값 호출 함수");
		double ran = Math.random();
		return ran;
	}
	static int dice() {
		System.out.println("주사위 랜덤 값");
		int ran = (int)(Math.random()*6+1);
		return ran;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ret1();  // 리턴값 없는, 리턴랎이 없는 경우 System.out.println(ret1()); 에러 발생
				 // int no = ret1(); 리턴값이 없기에 특정한 변수에 할당도 에러 발생
		System.out.println(ret2());  // 리턴값 25가 있기에 출력.
		int no2 = ret2();  // 리턴값 25가 no2에 할당 그전에 수행하는 문이 있으면 먼저 실행순서를 지키고 return값이 할당
		
		System.out.println("함수를 호출했을 때 : "+ret3());
		
		String str1 = ret4();
		System.out.println("str1 : "+str1);
		
		System.out.println(ret5());
		System.out.println(ret5());
		System.out.println(ret5());
		System.out.println(ret5());
		
		System.out.println(dice());
		int dice01 = dice();
		System.out.println(dice01);
		
	}

}
