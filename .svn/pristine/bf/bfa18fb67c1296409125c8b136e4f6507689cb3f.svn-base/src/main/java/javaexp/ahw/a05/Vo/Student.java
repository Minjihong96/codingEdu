package javaexp.ahw.a05.Vo;

public class Student {
	private String name;
	private int korScore;
	private int mathScore;
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public Student(String name, int korScore, int mathScore) {
		this.name = name;
		this.korScore = korScore;
		this.mathScore = mathScore;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getKorScore() {
		return korScore;
	}
	public void setKorScore(int korScore) {
		this.korScore = korScore;
	}
	public int getMathScore() {
		return mathScore;
	}
	public void setMathScore(int mathScore) {
		this.mathScore = mathScore;
	}
	
}
