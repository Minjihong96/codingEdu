package javaexp.ahw;

public class a0430 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Doll d01 = new Doll("핑크토끼","분홍색");
		Child ch01 = new Child("지우",d01);
		System.out.println("저는 "+ch01.getName()+"에요. 제 인형은 "+ch01.getDoll().getName()+"이고, 색깔은 "+ch01.getDoll().getColor()+"이에요!");
		Cake c01 = new Cake("초코릿 케이크","3단");
		Baker b01 = new Baker("민수", c01);
		System.out.println("제빵사 "+b01.getName()+"는 "+b01.getCake().getFlavor()+"("+b01.getCake().getLayer()+")을 만들었습니다.");
		Painting p01 = new Painting("봄의 정원","120x80");
		Artist a01 = new Artist("윤슬",p01);
		System.out.println("화가 "+a01.getName()+"의 작품 "+"\'"+a01.getPainting().getName()+"\'은 크기 "+a01.getPainting().getWidth()+"입니다.");

	}

}
/*

### 5. 🎨 [Java] 화가와 그림

**이야기**:  
화가는 하나의 작품을 소중히 소유하고 있어요. 그림은 제목과 크기(가로x세로)를 가지고 있어요.

**요구사항**:  
- `Artist` 클래스와 `Painting` 클래스를 생성하고 1:1 관계로 구성하세요.  
- 화가가 자신의 그림을 설명하는 메서드를 구현하세요.  
> 출력 예시:  
> “화가 윤슬이의 작품 ‘봄의 정원’은 크기 120x80입니다.”

*/
class Painting{
	private String name;
	private String width;
	public Painting(String name, String width) {
		this.name = name;
		this.width = width;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	
}
class Artist{
	private String name;
	private Painting painting;
	public Artist(String name, Painting painting) {
		this.name = name;
		this.painting = painting;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Painting getPainting() {
		return painting;
	}
	public void setPainting(Painting painting) {
		this.painting = painting;
	}
	
}

class Doll{
	private String name;
	private String color;
	public Doll(String name, String color) {
		this.name = name;
		this.color = color;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
}
class Child{
	private String name;
	private Doll doll;
	public Child(String name, Doll doll) {
		this.name = name;
		this.doll = doll;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Doll getDoll() {
		return doll;
	}
	public void setDoll(Doll doll) {
		this.doll = doll;
	}
	
}

class Cake{
	private String flavor;
	private String layer;
	public Cake(String flavor, String layer) {
		this.flavor = flavor;
		this.layer = layer;
	}
	
	public String getFlavor() {
		return flavor;
	}
	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}
	public String getLayer() {
		return layer;
	}
	public void setLayer(String layer) {
		this.layer = layer;
	}
	
}
class Baker{
	private String name;
	private Cake cake;
	public Baker(String name, Cake cake) {
		this.name = name;
		this.cake = cake;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Cake getCake() {
		return cake;
	}
	public void setCake(Cake cake) {
		this.cake = cake;
	}
	
}