package javaexp.a08_object.a04_relation;

public class A01_1_OneAndOneReview {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pet p01 = new Pet(); // 종속되지 않는 Pet 객체 (아직 주인이 없는 애완동물)
		PetOwner po01 = new PetOwner();
		// Pet을 가질 수 있는 주인 객체 생성(아직 애완동물은 없지만 가질 수 있는 객체 생성)
		po01.pet = p01; // 1:1 관계 성립으로 Pet은 주인에게 종속된 애완 동물이 되고, 주인도 Pet을 가진 주인으로 객체를 가지게 된다.
		po01.pet.name = "귀염둥이1";
		po01.pet.age = 5;
		
		Book3 b01 = new Book3("반지의 제왕",35000);
		BookBuyer bo01 = new BookBuyer(b01);
		bo01.Bookshow();
		
		Adress ad =new Adress();
		House hu = new House();
		hu.adress1 = ad;
		hu.adress1.street = "야탑로 20";
		hu.adress1.city = "분당구 ";
		System.out.println("경기도 성남시 "+hu.adress1.city+hu.adress1.street);
		
	}

}
// Address, House 1:1 관계 선언, House객체에 Address객체 할당 Address속성을 street, city설정
class Adress{
	String street;
	String city;
}
class House{
	Adress adress1;
}
// ex) Book, BookBuyer 1:1 관계 클래스 선언후, 객체에 할당하고, Book의 속성 title, price를 설정해보세요
class Book3{
	private String title;
	private int price;
	public Book3(String title, int price) {
		this.title = title;
		this.price = price;
	}
	public String getTitle() {
		return title;
	}
	public int getPrice() {
		return price;
	}
	
}
class BookBuyer{
	Book3 book1;

	public BookBuyer(Book3 book1) {
		this.book1 = book1;
	}
	public void Bookshow() {
		System.out.println("책 제목 : "+book1.getTitle());
		System.out.println("가격 : "+book1.getPrice());
	}
	
}

/*
# 1:1관계
1. 객체 안에 객체를 설정하는 것을 말한다.
*/
// 포함될 객체를 위한 클래스 선언
class Pet{
	String name;
	int age;
}
// 포함할 객체를 위한 클래스 선언
class PetOwner{
	Pet pet;
}
