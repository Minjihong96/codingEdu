package javaexp.ahw.a05;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javaexp.a10_database.DB;

public class A0512 {
	
	public List<String> getEnameDeptno(int deptno){
		List<String> ename = new ArrayList<String>();
		String sql = "SELECT ENAME FROM EMP WHERE DEPTNO = ?";
		try(Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setInt(1, deptno);
				try(ResultSet rs = pstmt.executeQuery()){
					while(rs.next()) {   
						ename.add(rs.getString("ENAME"));
					}
					System.out.println("데이터 로딩 완료:"+ename.size());				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return ename;
	}
	
	public List<Integer> getMgrSal(double sal){
		List<Integer> mgr = new ArrayList<Integer>();
		String sql = "SELECT MGR FROM EMP WHERE SAL = ?";
		try(Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setDouble(1, sal);
				try(ResultSet rs = pstmt.executeQuery()){
					while(rs.next()) {   
						mgr.add(rs.getInt("MGR"));
					}
					System.out.println("데이터 로딩 완료:"+mgr.size());				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		
		return mgr;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A0512 dao = new A0512();
		for(String ename:dao.getEnameDeptno(30)) {
			System.out.println(ename);
		}
		for(int mgr:dao.getMgrSal(1250)) {
			System.out.println(mgr);
		}

	}

}
