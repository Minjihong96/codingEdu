package javaexp.ahw;

public class a0410_3 {
	
	static int rollDice() {
		int ran = (int)(Math.random()*6+1);
		return ran;
	}

	public static void main(String[] args) {
		
		System.out.println(rollDice());
		System.out.println(rollDice());
		System.out.println(rollDice());

	}

}
