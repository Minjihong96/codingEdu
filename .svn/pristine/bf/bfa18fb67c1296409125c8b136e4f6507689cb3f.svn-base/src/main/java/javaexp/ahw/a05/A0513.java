package javaexp.ahw.a05;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javaexp.a10_database.DB;
import javaexp.ahw.a05.Vo.Car;
import javaexp.ahw.a05.Vo.Dept;
import javaexp.ahw.a05.Vo.Student;

public class A0513 {
	
	public String DnameByDname(String dname){
		String dnam = "";
		String sql = "SELECT DNAME FROM DEPT WHERE DNAME = ?";
		try( Connection con = DB.con();
				PreparedStatement pstmt = con.prepareStatement(sql);){
				pstmt.setString(1, dname); // ? 에 있는 1번째 데이터 할당 처리
				try(ResultSet rs = pstmt.executeQuery()){
					if(rs.next()) {   // 한개 행 리턴
						dnam=rs.getString("DNAME");
					}
					System.out.println("데이터 로딩 완료:");				
				}
			}catch(SQLException e) {
				System.out.println("DB처리 에러:"+e.getMessage());
			}catch(Exception e) {
				System.out.println("기타 에러:"+e.getMessage());
			}
		return dnam;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A0513 dao = new A0513();
		System.out.println(dao.DnameByDname("ACCOUNTING"));
		
		Student st = new Student("홍길동", 90, 80);
		System.out.println(st.getName());
		System.out.println(st.getKorScore());
		System.out.println(st.getMathScore());
		
		Date now = new Date();
		Car c1 = new Car("현대자동차","그렌저",now);
		System.out.println(c1.getMake());
		System.out.println(c1.getModel());
		System.out.println(c1.getYear());
		List<Car> car = new ArrayList<Car>();
		car.add(new Car("현대자동차","그렌저",now));
		car.add(new Car("기아자동차","소나타",now));
		car.add(new Car("bmw","g80",now));
		for(Car ca:car) {
			System.out.print(ca.getMake()+"\t");
			System.out.print(ca.getModel()+"\t");
			System.out.print(ca.getYear()+"\n");
		}
		List<Dept> dp = new ArrayList<Dept>();
		dp.add(new Dept(1,"회계","부산"));
		dp.add(new Dept(2,"전산","서울"));
		dp.add(new Dept(3,"기계","대구"));
		for(Dept d:dp) {
			System.out.print(d.getDeptNo()+"\t");
			System.out.print(d.getDeptName()+"\t");
			System.out.print(d.getLocation()+"\n");
		}

	}

}
