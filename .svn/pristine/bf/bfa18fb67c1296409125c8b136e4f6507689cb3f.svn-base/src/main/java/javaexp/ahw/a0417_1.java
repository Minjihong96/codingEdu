package javaexp.ahw;

public class a0417_1 {

	public static void main(String[] args) {
		Student st = new Student("이기찬","3학년1반",15);
		st.showst();

	}

}
class Student{
	String name;
	String group;
	int num;
	public Student(String name, String group, int num) {
		this.name = name;
		this.group = group;
		this.num = num;
	}
	void showst() {
		System.out.println("이름 : "+name);
		System.out.println("학년 : "+group);
		System.out.println("번호 : "+num);
	}
}