package javaexp.a03_calcu;

public class A0326 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		  정수 변수 `start(3)`와 `step(5)`을 할당하여, `start`에서 `start += step`  3회반복,  
		  `start -= step` 2회반복 결과를 순서대로 출력하는 프로그램을 작성해보세요.
		 */
		int start = 3;
		int step = 5;
		System.out.println("나오는 출력 값 : "+(start +=step));
		System.out.println("나오는 출력 값 : "+(start +=step));
		System.out.println("나오는 출력 값 : "+(start +=step));
		System.out.println("나오는 출력 값 : "+(start -=step));
		System.out.println("나오는 출력 값 : "+(start -=step));

	}

}
