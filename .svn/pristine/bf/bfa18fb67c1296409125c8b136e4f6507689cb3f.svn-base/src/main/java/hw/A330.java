package hw;

public class A330 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 1. **🚶‍♂️헬스장 방문기록 시뮬레이션**  
         	- 오늘 방문 횟수를 0부터 시작하여 매번 ++ 연산자를 사용해 5일간 방문 횟수를 출력해보세요.
		 */
		int visit =0;
		visit++; visit++; visit++; visit++; visit++;
		System.out.println("5일간 총 방문 횟수 : "+visit);
		/*
		 2. **🍩도넛 나눠 먹기**  
   			- 도넛이 10개 있습니다. 친구 3명에게 똑같이 나눠주고 남은 도넛 수를 출력하세요.
		 */
		int donut = 10;
		System.out.println("친구 3명에게 똑같이 나눠주고 남은 도넛 수 : "+(donut%3));
		/*
		 3. **🎯게임 점수 계산기**  
   			- 점수가 50부터 시작합니다. 보스를 잡으면 `+30`, 몬스터를 잡으면 `+10`입니다. 각 상황을 가정하여 점수 합계를 출력하세요.
		 */
		int point = 50;
		int bossPoint = 30;
		int monsterPoint = 10;
		System.out.println("보스만 잡았을 경우 점수 : "+(point+bossPoint));
		System.out.println("몬스터 1마리만 잡았을 경우 점수 : "+(point+monsterPoint));
		System.out.println("보스와 몬스터 1마리만 잡았을 경우 점수 : "+(point+monsterPoint+bossPoint));
		/*
		 4. **🎢놀이기구 탑승 조건 검사기**  
   			- 나이가 10세 이상이고 키가 120cm 이상일 때만 탑승 가능합니다. 조건을 만족하는지 검사해보세요.
		 */
		int age = 9;
		int height = 140;
		System.out.println("탑스 가능 여부 : "+(age>=10 && height>=120 ? "가능" : "불가능"));
		/*
		 5. **🧃주스 자판기 시뮬레이션**  
   			- 주스는 8개가 있고, 사람마다 한 개씩 가져가면 개수가 하나씩 줄어듭니다. 모두 가져갈 때까지 남은 개수를 출력하세요.
		 */
		int juice=8;
		juice--; juice--; juice--; juice--; juice--; juice--; juice--; juice--;
		System.out.println("남은 주스 갯수 : "+juice);
		/*
		 6. **🚌버스 요금 계산기**  
   			- 기본 요금 1,200원, 10분 초과 시마다 100원씩 추가됩니다. 총 35분을 탑승했다면 총 요금을 계산하세요.
		 */
		int publicTax = 1200;
		double time = 2.5;
		double addTax = time*100;
		double totalTax = publicTax+addTax;
		System.out.println("35분을 탑승시 총 요금 : "+ (int)totalTax);
		/*
		 7. **📚도서관 대출일 계산기**  
   			- 책 2권의 대출일을 비교하여 더 오래 대출 중인 책을 출력하세요.
		 */
		int book1 =15; int book2 = 10;
		System.out.println("더 오래 대출 중인 책 : "+(book1>book2 ? "book1" : "book2"));
		/*
		 8. **🍔햄버거 주문 계산기**  
   			- 햄버거는 개당 4,500원. 3개 주문 시 총 가격을 계산하고, 10,000원으로 계산 시 거스름돈도 함께 출력하세요.
		 */
		int hamPrice =4500; int order =3; int money=10000;
		int totalPrice = hamPrice*order;
		int change = money-totalPrice;
		System.out.println("총 가격 : "+totalPrice);
		System.out.println("거스름돈 : "+change);
		/*
		 9. **🎓시험 합격 여부 판단기**  
   			- 국어, 영어 점수가 모두 60점 이상이면 합격입니다. 조건에 따라 "합격" 또는 "불합격"을 출력하세요.
		 */
		int kor=70; int eng=80;
		System.out.println("시험 합격 여부 : "+(kor>=60 && eng>=60 ? "합격" : "불합격"));
		/*
		 10. **🎈풍선 터뜨리기 게임**  
    		 - 풍선은 10개. `--` 연산자를 사용하여 하나씩 터뜨릴 때마다 남은 개수를 출력하세요.
		 */
		int balloon =10;
		balloon--; balloon--; balloon--; balloon--; balloon--; balloon--; balloon--; balloon--; balloon--; balloon--;
		System.out.println("남은 갯수" + balloon);
		/*
		 11. **👮성인 인증 시스템**  
    		 - 나이를 입력하고, 18세 이상이면 "성인입니다", 아니면 "미성년자입니다"를 삼항 연산자로 출력하세요.
		 */
		int age2=19;
		System.out.println("성인입니까? : "+(age2>=18 ?"성인입니다":"미성년자입니다"));
		/*
		 12. **⛳퍼팅 게임 점수판**  
    		 - `홀1: 2타`, `홀2: 3타`, `홀3: 4타`. 총 타수를 계산하고, 10타 이하이면 "굿샷!", 아니면 "연습 필요!"를 출력하세요.
		 */
		int hole1=2; int hole2=3; int hole3=4;
		int totalhole = hole1+hole2+hole3;
		System.out.println("총 타수 : "+totalhole);
		System.out.println(totalhole<=10 ?"굿샷!":"연습 필요!");
		/*
		 13. **🎤가수 콘테스트**  
    		 - 노래점수와 무대매너 점수를 입력받고, 둘 다 80점 이상이면 결선 진출이라고 출력하세요.
		 */
		int singsco=90; int maner=95;
		boolean final1 = (singsco>=80 && maner>=80);
		System.out.println(final1 ?"결선 진출":"결선 미진출");
		/*
		 14. **🛍️마켓 할인 조건 확인기**  
    		 - 구매금액이 5만원 이상이거나 쿠폰을 가진 경우 할인 적용. 조건에 따라 할인 여부를 출력하세요.
		 */
		int totalPrice2 = 45000;
		boolean coupon= true;
		boolean disCount =  (totalPrice2>=50000 || coupon);
		System.out.println("할인 가능 ? " + disCount);
		/*
		 15. **🧩두 숫자 비교게임**  
    		 - 두 숫자를 입력하고, 더 큰 수가 무엇인지 출력하세요.
		 */
		int num1= 20; int num2=30;
		int num3 = (num1>num2) ?num1 :num2;
		System.out.println("num1과 num2중 더 큰 수 : "+num3);
		/*
		 16. **🚙주차요금 시뮬레이션**  
			 - 시간당 2,000원, 3시간 주차했을 때 총 요금 계산하여 출력하세요.
		 */
		int tax2=2000; int time2= 3;
		int totalFree =tax2*time2;
		System.out.println("총 요금 : "+totalFree);
		/*
		 17. **🎮레벨업 조건 검사기**  
    	     - 경험치가 500 이상이면 레벨업. 현재 경험치를 입력하고 결과를 출력하세요.
		 */
		int exp=600;
		System.out.println("레벨업 유무 : "+(exp>=500 ?"레벨 업" :"레벨 업 못함"));
		/*
		 18. **🍽️식당 테이블 예약 확인기**  
    	     - 예약된 테이블 수가 5개 이하이면 "예약 가능", 그렇지 않으면 "예약 마감" 출력하세요.
		 */
		int res =4;
		System.out.println("예약 가능한가? "+(res<=5 ?"예약 가능" :"예약 마감"));
		/*
		 19. **📦택배 박스 용량 계산기**  
    		 - 박스 하나에 5개씩 물건이 들어간다고 할 때, 총 물건 23개를 포장할 경우 필요한 박스 수와 남는 물건 수를 출력하세요.
		 */
		int object = 5;
		int totalObject = 23;
		System.out.println("필요한 박스 수 : "+(totalObject/object));
		System.out.println("남은 물건 수 : "+(totalObject%object));
		/*
		 20. **🏝️여행 조건 확인기**  
    	     - 나이가 20세 이상이고 여권이 있으면 해외여행 가능. 조건을 비교하고 결과 출력하세요.
		 */
		int age3=20;
		boolean travel= true;
		System.out.println("해외여행 가능 여부 : "+(age3>=20 && travel ?"여행 가능" :"불가능"));
		
		
		
		
	}

}
