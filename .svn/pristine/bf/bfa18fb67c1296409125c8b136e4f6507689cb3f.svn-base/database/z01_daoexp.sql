-- 1. SQL(1행 1열)
-- 사원의 갯수
SELECT COUNT(*) CNT FROM EMP WHERE DEPTNO=10;
-- 2. 입력/출력값 정리
-- 입력값 부서번호 int
-- 출력 갯수 int
-- 3. 메서드 선언
/*
public int getCountEmp(int deptno){
	int count=0;
	String sql = "SELECT COUNT(*) CNT FROM EMP WHERE DEPTNO=?";
	
	return count;
}
*/

-- 4. try catch문 복사
-- 5. pstmt.setXxx 설정
--	  매개변수로 데이터를 ? 연결 처리
-- 6. rs.next(), rs.getXxx()
--	  결과를 처리해주는 내용
SELECT * FROM EMP;
-- sql을 통한 메서드 선언 연습문제
-- 1. 사원번호를 통하여 급여를 처리하는 sql과 메서드를 선언하세요.
SELECT SAL FROM EMP WHERE EMPNO = 7369;
/*
public double getSalbyEmpno(int empno){
	double sal = 0;
	String sql = "SELECT SAL FROM EMP WHERE EMPNO = ?";
	
	return sal;
}
*/
-- 2. 사원명을 통하여 사원번호를 처리하는 sql과 메서드를 선언
SELECT EMPNO FROM EMP WHERE ENAME = 'ALLEN';
/*
public int getEmpnobyEname(String ename){
	int empno = 0;
	String sql = "SELECT EMPNO FROM EMP WHERE ENAME = ?";
	
	return empno;
}
*/
-- 3. 급여를 통하여 직책을 처리하는 sql과 메서드를 선언
SELECT JOB FROM EMP WHERE SAL = 2975;
/*
public String getJobbySal(double sal){
	String job = "";
	String sql = "SELECT JOB FROM EMP WHERE SAL = ?";
	
	return job;
}
*/

-- 1. SQL(다수행 1열)
SELECT ENAME FROM EMP WHERE DEPTNO = 10;
-- 2. 입력/출력값 정리
--	  입력 : int deptno
--	  결과값 : List<String> ename = new ArrayList<String>();
-- 결과값의 유형들 List<Integer>(정수형) List<Date>(날짜) List<Double>(실수형) List<String>(문자열)
-- 3. 메서드 선언
/*
public List<String> getEnamesByDeptno(int deptno){
	List<String> enames = new ArrayList<String>();
	String sql = "SELECT ENAME FROM EMP WHERE DEPTNO = ?";
	
	return enames;
}
*/
-- 4. try catch문 복사
-- 5. pstmt.setXxx 설정
-- 6. rs.next(), rs.getXxx()

-- 다수행 1열 sql 처리 메서드 선언 연습
SELECT * FROM EMP;
-- 1. 직책별로 사원명을 검색하는 메서드 선언
SELECT ENAME FROM EMP WHERE JOB = 'CLERK';
/*
public List<String> getEnamesbyJob(String job){
	List<String> enames = new ArrayList<String>();
	String sql = "SELECT ENAME FROM EMP WHERE JOB = ?";
	
	return enames;
} 
*/
-- 2. 관리자별로 사원번호를 검색하는 메서드 선언
SELECT EMPNO FROM EMP WHERE MGR = 7698;
/*
public List<Integer> getEmpnosbyMgr(int mgr){
	List<Integer> empnos = new ArrayList<Integer>();
	String sql = "SELECT EMPNO FROM EMP WHERE MGR = ?";
	
	return empnos;
}  
*/
-- 3. 부서별로 급여를 검색하는 메서드 선언
SELECT SAL FROM EMP WHERE DEPTNO = 10;
/*
public List<Double> getSalsbyDeptno(int deptno){
	List<Double> sals = new ArrayList<Double>();
	String sql = "SELECT SAL FROM EMP WHERE DEPTNO = ?";
	
	return sals;
}  
*/
-- 다중행, 다중열 연습
SELECT SAL, ENAME FROM EMP WHERE DEPTNO = 10 OR JOB = 'CLERK';
/*
public List<Emp> getSalEname(int deptno, String job){
	List<Emp> list = new ArrayList<Emp>();
	String sql = "SELECT SAL, ENAME FROM EMP WHERE DEPTNO = ? OR JOB = ?";
	
	return list;
}
*/
-- 1. SQL
SELECT * FROM DEPT WHERE DEPTNO = 10;
-- 2. 입력/출력값 정리
-- 입력 : int deptno
-- 출력 : int deptno, String dname, String loc;
--		필드명 ==> 컬러명 소문자, 
--		데이터 유형
--		VARCHAR2(), VARCHAR() ==> String
--		NUMBER(7,2) ==> double
--		NUMBER(4,0) ==> int
--		DATE	==> Date(java.util.Date)
--		==> Dto 객체 필요 class Dept
-- 3. 메서드 선언 : 다중열(받기위해서 Dto객체를 생성 처리)
/*
public Dept getDeptByDeptno(int deptno){
	Dept dept = null;
	String sql = "SELECT * FROM DEPT WHERE DEPTNO = ?";
	
	return dept;
} 
*/
-- 4. try catch문 복사
-- 5. pstmt.setXxx 설정
-- 6. rs.next(), rs.getXxx()

SELECT * FROM STUDENT WHERE NO =1;
-- 위 내용을 처리하기 위한 Dto(Student)
-- 입력 : int no;
-- 출력 : int no; String name; int kor; int eng; int math;
/*
class Student{
	private int no;
	private String name;
	private int kor;
	private int eng;
	private int math;
	// 생성자. get/set 메서드 생성.
}
*/
/*
public Student getStudentByNo(int no){
	Student student = null;
	String sql = "SELECT * FROM STUDENT WHERE NO = ?";
	
	return student;
}
*/
SELECT * FROM CART_ITEM;
SELECT * FROM CART_ITEM WHERE CART_ID=1;
-- EX) 위 기준 DTO 만들기 class인 CartItem
/*
class CartItem{
	private int cart_id;
	private int user_id;
	private String product_name;
	private int quantity;
	private int price_per_item;
	private Date added_date;
}
*/

-- 1. SQL
SELECT * FROM DEPT WHERE DNAME LIKE '%A%' AND LOC LIKE '%A%';
-- 2. 입력/출력값 정리
/*
입력 : String dname, String loc ===> class Dept(여러개의 입력값을 위해 DTO)
출력 : int deptno, String dname, String loc 
		==> class Dept(다중열) ==> List<Dept> (다중행)
**/
-- 3. 메서드 선언
/*
public List<Dept> getDeptList(Dept sch){
	List<Dept> dlist = new ArrayList<Dept>();
	String sql = "SELECT * FROM DEPT WHERE DNAME LIKE ? AND LOC LIKE ?";
	return dlist;
}
 * */
-- 4. try catch문 복사
-- 5. pstmt.setXXX 설정
---   pstmt.setString(1, sch.getDname());
---   pstmt.setString(2, sch.getLoc());
-- 6. rs.next(), rs.getXXX()
--    while(rs.next()){
--      list.add(new Dept(rs.getInt("DEPTNO"), rs.getString("DNAME"), rs.getString("LOC")));
--  }

-- 
SELECT * FROM EMP;
--  부서번호와 직책을 통해서 검색된 내용을 처리하는 DAO 메서드를 만들어 보세요..
-- 1. SQL
SELECT * FROM EMP WHERE DEPTNO = 30 AND JOB  = 'SALESMAN';
---------------------
-- 2. 입력 : int deptno, String job ==> Emp( int deptno, String job)
--    출력   int empno, String ename, String job, int mgr, Date hiredate, double sal,
--          double comm, int deptno ==> Emp(..전체 데이터 처리..)여러열 ==> List<Emp> 여러행
-- 3. class 생성자, 선언
----------------------------------------------
-- 4. 메서드 선언
----------------
/*
리턴 ==> 출력의해서
입력 ==> 매개변수로
public List<Emp> getEmpList(Emp sch){
	List<Emp> list = new ArrayList<Emp>();
	String sql = "SELECT * FROM EMP WHERE DEPTNO = ? AND JOB  = ?";
	
	return list;
}
*/
-- 5. try 복사
-- 6. pstmt 설정
-- 7. rs 설정

SELECT * FROM ORDERS
WHERE WIZARD_NAME LIKE '%Potter%'
	AND ORDER_AMOUNT BETWEEN 100 AND 200;
/*
입력 : String wizardName, int frOrder, int toOrder
출력 : int orderId, String wizardName, Date orderDate, int orderAmount
public List<Orders> getOrdersList(Orders sch){
	List<Orders> list = new ArrayList<Orders>();
	String sql = "SELECT * FROM ORDERs WHERE WIZARD_NAME LIKE ? AND ORDER_AMOUNT BETWEEN ? AND ?";
	return list;
}
*/

SELECT DNAME FROM DEPT WHERE DNAME = 'ACCOUNTING';
/*
public String DnameByDname(String dname){
	String dnam = "";
	String sql = "SELECT DNAME FROM DEPT WHERE DNAME = ?";
	
	return dnam;
}
*/