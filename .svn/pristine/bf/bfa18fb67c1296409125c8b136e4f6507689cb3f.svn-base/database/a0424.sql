SELECT * FROM EMP;
SELECT ENAME, NVL2(JOB,'출연자','대기자') "직책명"
FROM EMP01;

SELECT ENAME, JOB, NVL2(JOB,'조리 담당','대기자') "직책구분"
FROM EMP01;

SELECT ENAME, SAL, NULLIF(SAL,3000) "처리급여"
FROM EMP;

SELECT ENAME, UPPER(ENAME), SUBSTR(ENAME, 1, 2) "예술 이름"
FROM EMP;

SELECT CONCAT(ENAME, EMPNO) "고유 ID", CONCAT(DEPTNO,'-'||EMPNO) "프로그래머 ID"
FROM EMP;

SELECT ENAME, JOB, NVL2(JOB, '출연 확정', '캐스팅 대기') "출연상태"
FROM EMP01;

SELECT ENAME, SAL, SAL*1.1 "NEW_SALARY"
FROM EMP;

SELECT ENAME, HIREDATE, CEIL((SYSDATE-HIREDATE)/365) "근속년수"
FROM EMP;
/*

### 🔵 문제 2. "사원 근속 연수 구하기"

**설명:**  
- `EMP` 테이블에서 각 사원의 입사일(`HIREDATE`)을 기준으로 현재까지 근속연수를 계산하세요.  
- 근속연수는 소수점 없이 정수 연도(`YEARS`)로 표시하세요.  
- 출력 컬럼: 사원명(`ENAME`), 입사일(`HIREDATE`), 근속연수(`YEARS`)

*/