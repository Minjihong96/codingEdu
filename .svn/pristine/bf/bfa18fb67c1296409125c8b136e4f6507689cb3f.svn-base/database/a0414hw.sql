/*
3. 🎤 **사원 인터뷰 게시판 만들기**  
   ‘EMP’ 테이블에서 `ENAME`, `JOB`, `SAL` 데이터를 활용해  
   - 각 사원 인터뷰 내용을 article로 구성하고  
   - CSS로 테두리와 배경색을 지정해보세요.

4. 📊 **직책별 급여 순위 페이지 만들기**  
   SQL로 `JOB DESC, SAL ASC`로 정렬된 결과를  
   - HTML에 테이블 형태로 출력하고  
   - 각 `JOB`별로 다른 배경색을 적용하세요.

5. 🔍 **사원명 검색 인터페이스 만들기**  
   사용자가 사원명에 포함된 키워드를 입력하면  
   - LIKE '%A%' 조건으로 검색해  
   - 검색 결과를 출력하는 HTML 틀을 만들고 설명을 적으세요.

6. 🕵️‍♀️ **숨은 사원 찾기 게임**  
   ENAME이 ‘_I__’과 같은 형식에 맞는 사원을 찾는 퀴즈를 만드세요.  
   - HTML로 문제를 만들고  
   - 정답은 SQL로 설명합니다.

*/
SELECT ENAME, JOB, SAL
FROM EMP;
SELECT ENAME, JOB, SAL
FROM EMP
ORDER BY JOB DESC, SAL;
SELECT ENAME
FROM EMP
WHERE ENAME LIKE '%A%';
SELECT ENAME
FROM EMP
WHERE ENAME LIKE '_I__';
/*
### 🏥 **1. 병원 진료 기록 관리 시스템**

> 병원에서는 환자의 진료 정보를 기록합니다.  
> 환자 이름, 진료과목, 진료일, 의사 이름, 진료비를 저장하세요.

#### 📌 요구사항
- `MEDICAL_RECORD` 테이블 생성  
- 3건 이상 데이터 입력  
- 2025년 4월 이후에 진료받은 환자만 조회

```sql
SELECT * 
FROM LIBRARY_LOAN 
WHERE RETURN_DUE < TO_DATE('2025-04-20','YYYY-MM-DD');
```
 */
CREATE TABLE MEDICAL_LOAN(
	NAME VARCHAR(50),
	TREATMENT VARCHAR(50),
	RETURN_DUE DATE,
	MEDICAL_NAME VARCHAR(50),
	PRICE NUMBER
);
SELECT TO_DATE('2025-04-05 17:50', 'YYYY-MM-DD HH24:MI') FROM DUAL;
SELECT * FROM MEDICAL_LOAN;
INSERT INTO MEDICAL_LOAN
VALUES('이기찬','류마티스내과',TO_DATE('2025-04-18','YYYY-MM-DD'), '홍길동', 50000);
INSERT INTO MEDICAL_LOAN
VALUES('김기찬','류마티스내과',TO_DATE('2025-04-25','YYYY-MM-DD'), '홍길동', 50000);
INSERT INTO MEDICAL_LOAN
VALUES('신기찬','류마티스내과',TO_DATE('2025-04-20','YYYY-MM-DD'), '홍길동', 50000);
COMMIT;
SELECT *
FROM MEDICAL_LOAN 
WHERE RETURN_DUE < TO_DATE('2025-04-20','YYYY-MM-DD');

/*
### 📦 **2. 창고 재고 관리 시스템**

> 물류창고에서 보관 중인 물품의 정보를 관리합니다.

#### 📌 요구사항
- `WAREHOUSE_ITEM` 테이블 생성  

- 식품, 전자기기 등 다양한 물품으로 3건 이상 입력  
- 수량이 50개 이상인 물품만 조회
 
*/
CREATE TABLE WAREHOUSE_ITEM(
	PRODUCT VARCHAR(100),
	QUANTITY NUMBER
);
SELECT * FROM WAREHOUSE_ITEM;
INSERT INTO WAREHOUSE_ITEM 
VALUES('콜라', 100);
INSERT INTO WAREHOUSE_ITEM 
VALUES('사이다', 80);
INSERT INTO WAREHOUSE_ITEM 
VALUES('생수', 40);
INSERT INTO WAREHOUSE_ITEM 
VALUES('라면', 70);
INSERT INTO WAREHOUSE_ITEM 
VALUES('햇반', 30);
COMMIT;
SELECT *
FROM WAREHOUSE_ITEM
WHERE QUANTITY >= 50;

/*
#### 📌 요구사항
- `EVENT_ENTRY` 테이블 생성  
  - `ENTRY_ID` NUMBER  
  - `CUSTOMER_NAME` VARCHAR2(50)  
  - `EVENT_NAME` VARCHAR2(100)  
  - `ENTRY_DATE` DATE  
  - `ENTRY_CHANNEL` VARCHAR2(30)  

- 3건 이상의 데이터 입력  
- `ENTRY_CHANNEL`이 `'모바일'`인 데이터만 조회

```sql
SELECT * 
FROM EVENT_ENTRY 
WHERE ENTRY_CHANNEL = '모바일'; 
*/
CREATE TABLE EVENT_ENTRY(
	ENTRY_ID NUMBER,
	CUSTOMER_NAME VARCHAR2(50),
	EVENT_NAME VARCHAR2(100),
	ENTRY_DATE DATE,
	ENTRY_CHANNEL VARCHAR2(30)
);
SELECT * FROM EVENT_ENTRY;
INSERT INTO EVENT_ENTRY
VALUES(1, '홍길동','스마트폰 증정',SYSDATE,'모바일');
INSERT INTO EVENT_ENTRY
VALUES(2, '신길동','스마트폰 증정',SYSDATE,'현장응모');
INSERT INTO EVENT_ENTRY
VALUES(3, '김길동','스마트폰 증정',SYSDATE,'모바일');
SELECT * 
FROM EVENT_ENTRY 
WHERE ENTRY_CHANNEL = '모바일'; 

CREATE TABLE STUDENT1(
	STUDENT_NAME VARCHAR2(50),
	STUDENT_AGE NUMBER,
	STUDENT_DEPARTMENT VARCHAR2(100)
);
SELECT * FROM STUDENT1;
INSERT INTO STUDENT1
VALUES('홍길동',25,'컴퓨터공학과');
COMMIT;
CREATE TABLE MOVIE_RESERVATION(
	TITLE VARCHAR2(100),
	RESERVATION_NAME VARCHAR2(100),
	TIME DATE
);
SELECT * FROM MOVIE_RESERVATION;
INSERT INTO MOVIE_RESERVATION
VALUES('레미제라블','이기찬',TO_DATE('2025-04-15 11:15','YYYY-MM-DD HH24:MI'));
DROP TABLE MOVIE_RESERVATION;
CREATE TABLE BOOK(
	TITLE VARCHAR2(100),
	CHECK_OUT VARCHAR2(100)
);
SELECT * FROM BOOK;
INSERT INTO BOOK 
VALUES('JAVA입문서',NULL);
/*
4. 📚 **마법 도서 대출 관리 시스템**  
   `MAGIC_BOOK_LOG` 테이블을 생성하고 다음 필드 포함:  
   `BOOK_ID`, `STUDENT_NAME`, `BOOK_TITLE`, `BORROW_DATE`, `RETURN_STATUS`  
   ➤ 데이터를 다음과 같이 입력하세요:  
   `(1, '엘리자베스', '마법약의 역사', TO_DATE('2025-05-01','YYYY-MM-DD'), '미반납')`

5. 🚀 **우주선 정비 일정 관리 시스템**  
   `SHIP_MAINTENANCE` 테이블을 만들고 `SHIP_ID`, `SHIP_NAME`, `LAST_CHECK`, `STATUS` 컬럼 포함  
   ➤ `2025-04-30`에 `"스타플라이어"`가 `"정상"`으로 마지막 점검되었음을 입력하세요


*/
CREATE TABLE MAGIC_BOOK_LOG(
	BOOK_ID NUMBER,
	STUDENT_NAME VARCHAR2(50),
	BOOK_TITLE VARCHAR2(100),
	BORROW_DATE DATE,
	RETURN_STATUS VARCHAR2(50)
);
SELECT * FROM MAGIC_BOOK_LOG;
INSERT INTO MAGIC_BOOK_LOG VALUES(1, '엘리자베스', '마법약의 역사', TO_DATE('2025-05-01','YYYY-MM-DD'), '미반납');
COMMIT;
CREATE TABLE SHIP_MAINTENANCE(
	SHIP_ID NUMBER,
	SHIP_NAME VARCHAR2(100),
	LAST_CHECK DATE,
	STATUS VARCHAR2(50)
);
SELECT * FROM SHIP_MAINTENANCE;
INSERT INTO SHIP_MAINTENANCE VALUES(1, '스타플라이어', TO_DATE('2025-04-30','YYYY-MM-DD'), '정상');
SELECT LAST_CHECK || '에' || SHIP_NAME || '가' || STATUS || '으로 마지막 점검' ST
FROM SHIP_MAINTENANCE;