CREATE SEQUENCE members_seq
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;
CREATE TABLE members (
  member_id NUMBER PRIMARY KEY,
  username VARCHAR2(50) NOT NULL UNIQUE, -- id
  password VARCHAR2(255) NOT NULL,       -- 비밀번호 (암호화 저장 전제)
  name VARCHAR2(50) NOT NULL,
  gender VARCHAR2(10) CHECK (gender IN ('male', 'female')),
  birth_date DATE NOT NULL,             -- YYYY-MM-DD
  calendar_type VARCHAR2(10) CHECK (calendar_type IN ('solar', 'lunar')),
  phone VARCHAR2(20) NOT NULL,
  email VARCHAR2(100) NOT NULL,
  nickname VARCHAR2(50),
  agree_sms CHAR(1) DEFAULT 'N' CHECK (agree_sms IN ('Y', 'N')),
  agree_email CHAR(1) DEFAULT 'N' CHECK (agree_email IN ('Y', 'N')),
  agree_optional_terms CHAR(1) DEFAULT 'N' CHECK (agree_optional_terms IN ('Y', 'N')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE OR REPLACE TRIGGER trg_members_bi
BEFORE INSERT ON members
FOR EACH ROW
BEGIN
  SELECT members_seq.NEXTVAL INTO :NEW.member_id FROM dual;
END;
INSERT INTO members (
  username, password, name, gender, birth_date, calendar_type,
  phone, email, nickname, agree_sms, agree_email, agree_optional_terms
) VALUES (
  'john123', 'hashed_password', 'John', 'male', DATE '1990-05-01', 'solar',
  '01012345678', 'john@example.com', 'johnny', 'Y', 'N', 'N'
);
INSERT INTO members (
  username, password, name, gender, birth_date, calendar_type,
  phone, email, nickname, agree_sms, agree_email, agree_optional_terms
) VALUES (
  'rlcks', 'hashed_password', 'gichan', 'male', DATE '1991-10-25', 'solar',
  '01012345678', 'rlcks@example.com', 'gi', 'Y', 'N', 'N'
);
SELECT * FROM members;
SELECT * FROM v$version;
