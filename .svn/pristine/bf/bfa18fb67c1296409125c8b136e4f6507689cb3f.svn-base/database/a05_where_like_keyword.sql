SELECT * FROM EMP;
/*
 # 키워드 검색 LIKE
 1. 컬럼에서 LIKE를 사용하면 비슷한 키워드로 해당 내용을 검색 할 수 있다.
 2. 기본 형식
 	 1) WHERE 컬럼명 LIKE '%키워드%'; -- 해당 컬럼에서 키워드에 포함되면 모두 검색
 	 2) WHERE 컬럼명 LIKE '키워드%';  -- 해당 컬럼에서 키워드로 시작하면 검색
 	 3) WHERE 컬럼명 LIKE '%키워드';  -- 해당 컬럼에서 키워드로 종료하면 검색
 	 4) WHERE 컬럼명 LIKE '___;     -- 해당 자리수가 맞으면 검색(-(_언더바 3개))
 	 5) WHERE 컬럼명 LIKE '_A_';    -- 중간에 A가 포함되고 자리수가 3개이면 출력
 	 6) WHERE 컬럼명 LIKE '__A';    -- 자리수가 3개이고, 마지막에 A포함된 데이터 출력
 */
SELECT ENAME, JOB, SAL FROM EMP;
-- 앞뒤 상관없이 A 문자가 포함한 ENAMED이 있는 사원정보 ENAME, JOB, SAL 검색
SELECT ENAME, JOB, SAL FROM EMP WHERE ENAME LIKE '%A%';
-- EX) 앞뒤 상관업싱 M문자가 포함한 JOB이 있는 사원정보 ENAME JOB, SAL검색
SELECT ENAME, JOB, SAL -- 선택할 컬럼(열단위 선택)
FROM EMP -- 대상이 되는 테이블명
WHERE JOB LIKE '%M%'; -- WHERE 컬럼명 LIKE '%검색할키워드%' 행단위 FILTERING
SELECT * FROM EMP 
WHERE ENAME LIKE '%A%'; -- A시작, 중간A, 마지막A 다 포함

SELECT * FROM EMP 
WHERE ENAME LIKE 'A%';  -- A로 시작하는 데이터가 있는 사원명(ENAME)을 검색 
SELECT * FROM EMP 
WHERE ENAME LIKE 'W%'; -- W로 시작하는 데이터가 있는 사원명을 검색
SELECT * FROM EMP
WHERE JOB LIKE 'SAL%'; -- SAL로 시작하는 데이터가 있는 직책명을 검색

SELECT * FROM EMP 
WHERE ENAME LIKE '%S'; -- ENAME이 S로 끝나는 데이터가 있는 사원정보 검색
SELECT * FROM EMP 
WHERE JOB LIKE '%MAN'; -- JOB이 MAN로 끝나는 데이터가 있는 사원정보 검색
SELECT EMPNO , ENAME, JOB, SAL 
FROM EMP
WHERE JOB LIKE '%ER'; -- JOB이 ER로 끝나는 데이터가 있는 사원정보 검색

SELECT *
FROM EMP
WHERE ENAME LIKE '____'; -- LIKE '_의 갯수' 자리수
SELECT *
FROM EMP
WHERE ENAME LIKE '_____'; -- LIKE '_의 갯수' 자리수
SELECT *
FROM EMP
WHERE ENAME LIKE '__A__'; -- 자리수가 5개이며 세번째자리에 A가 포함되어 있을 때
SELECT *
FROM EMP
WHERE JOB LIKE '_____'; --  JOB에서 자리수가 5자리인 사원정보
SELECT *
FROM EMP
WHERE ENAME LIKE '_I__'; -- ENAME에서 자리수가 4자리이고 두번째 I를 포함한 사원정보
SELECT * FROM EMP WHERE JOB LIKE '__E__'; -- JOB이 총 5개의 자리에 중앙에 E가 있는 경우

SELECT * FROM EMP WHERE JOB LIKE '__E%'; -- JOB이 3번째자리가 E인 데이터
SELECT * FROM EMP WHERE JOB LIKE '%R_'; -- JOB이 뒤에서 2번째 데이터 R인 데이터
SELECT * FROM EMP
WHERE ENAME LIKE '__L%'; -- 앞에서 3번째 L이 포함된 사원명이 있는 사원정보
SELECT * FROM EMP
WHERE JOB LIKE '%S___'; -- 뒤에서 4번째 S가 포함된 직책이 있는 사원정보
-- EX1) 사원명이 B가 포함된 사원정보
-- EX2) 사원명이 앞에서 4, 5 번째가 ES 포함된 사원정보
-- EX3) 사원명이 세번째 자에서 M이 포함된 사원정보
-- EX4) 사원명이 자리수가 5자리이고, 중간에 I가 포함된 사원정보
SELECT * FROM EMP WHERE ENAME LIKE '%B%';
SELECT * FROM EMP WHERE ENAME LIKE '___ES%';
SELECT * FROM EMP WHERE ENAME LIKE '__M%';
SELECT * FROM EMP WHERE ENAME LIKE '__I__';

/*
5. **📚 도서 검색기 (SQL LIKE)**  
   - EMP 테이블에서 사원명이 'S'로 시작하는 데이터를 검색하는 SQL 문을 작성하세요.
6. **👨‍🍳 셰프의 재료 필터 (SQL IN)**  
   - EMP 테이블에서 직책이 'CLERK', 'SALESMAN', 'MANAGER'인 사원 정보를 검색하세요.
9. **🎥 영화관 좌석 필터 (SQL WHERE)**  
   - 급여가 2000 이상이면서 직책이 'MANAGER'인 사원만 출력하는 SQL문을 작성하세요.
*/
SELECT * FROM EMP WHERE ENAME LIKE 'S%';
SELECT *
FROM  EMP
WHERE JOB IN('CLERK', 'SALESMAN', 'MANAGER');

SELECT *
FROM EMP
WHERE SAL >= 2000 AND JOB >= 'MANAGER';