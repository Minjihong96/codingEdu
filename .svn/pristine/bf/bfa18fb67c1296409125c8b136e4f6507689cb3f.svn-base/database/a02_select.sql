SELECT * FROM emp;
SELECT EMPNO FROM EMP;
SELECT EMPNO NO FROM EMP;
SELECT EMPNO "# NO #" FROM EMP;
SELECT EMPNO || ' - ' || ENAME "사원번호와 사원명" FROM EMP;
SELECT ENAME, SAL, SAL*0.15 "급여의 15%" FROM EMP;
/*
 #데이터베이스 연결처리
 1. oracl은 '문자열1'||숫자형 등과 같이 문자와 문자, 문자와 숫자를 연결 처리한다.
 2. 숫자 + 숫자는 연산을 처리해준다.
 3. alias이름이 특수문자나 공백이 들어가면 ""로 처리한다.
 * */
SELECT ename||'님' 호칭, sal || deptno "숫자||숫자"
FROM emp;
-- ex) 다음의 컬럼을 '-' 문자열로 연결하여 출력하세요 
--     alias명은 사원명 사원번호, 직책과 관리자명으로
--	   ename - empno ==> 사원명과 사원번호
--     job - mgr ==> 잭책명과 관리자명
SELECT '사원명 : '||ename||', 사원번호 : '||empno||', 직책명 : '||job||'과 관리자명 : '||mgr info
FROM emp;
SELECT ename||'님' 사원명, empno 사원번호, job 직책, mgr 관리자
FROM emp;
SELECT ename || '-' || empno "사원명과 사원번호",
	   job || '-' || mgr "직책명과 관리자명"
FROM emp;
-- 데이터를 출력형식(ENAME || '-' || ENOPNO),
-- 컬럼(타이틀)나타내는 형식은 구분("사원명과 사원번호")
-- '문자열데이터', "별칭으로 타이틀로 나타낼 때"
-- ex) ename (deptno) ==> smith(20)
SELECT ename || '(' || deptno || ')' "사원명(부서명)"
FROM emp;