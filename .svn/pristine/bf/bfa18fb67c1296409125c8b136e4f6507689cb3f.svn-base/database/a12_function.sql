SELECT * FROM EMP;
/*
# 오라클 함수
1. ORACLE의 함수는 데이터베이스 내에서 데이터를 처리하고 계산하는 데, 중요한 역할을 합니다.
SQL 함수는 데이터를 변환하거나 계산하여 원하는 결과를 도출하는 데 사용합니다. 함수는 크게 집계함수,
문자열함수, 수학함수, 날짜 함수 등으로 구분 할 수 있습니다.
	1) 스칼라 함수 : 하나의 입력값을 받아서 하나의 출력 값을 반환하는 함수 입니다.
		예를 들어 UPPER, LOWER, ROUND, TRUNC 등이 있다.
	2) 집계 함수 : 여러 개의 입력 값들을 처리하여 하나의 출력 값을 반환하는 함수입니다.
		예를들어 SUM, COUNT, AVG, MAX, MIN 등이 있다.
2. ORACLE 함수의 분류 기준
	1) 문자열 함수(String Functions) : 문자열 데이터를 처리하는 함수입니다. 주로 텍스트의 조작,
		변환 등을 수행합니다.
		ex) UPPER, LOWER, SUBSTR, CONCAT
	2) 수학 함수(Mathenatical Functions) : 숫자 데이터를 처리하는 함수로, 숫자 계산이나 반올림 내림 등을 수행합니다.
		ex) ROUND, CEIL, FLOOR, MOD
	3) 날짜 함수(Date Functions) : 날짜와 시간을 처리하는 함수입니다. 날짜 간의 차이 계산, 날짜
		포맷 조정 등을 수행합니다.
		ex) SYSDATE, TO_DATE, ADD_MONTHS, MONTHS_BETWEEN
	4) 깁계 함수(Aggregate Functions) : 여러 개의 값들을 처리하여 하나의 결과값을 반환하는 함수
		ex) SUM, COUNT, AVG, MAX, MIN
	5) 변환 함수(Conversion Functions) : 데이터 타입을 변환하는 함수입니다.
		ex) TO_NUMBER, TO_CHAR, TO_DATE 
*/
/*
# 그룹함수
1. 테이블의 전체 행을 하나 이상의 컬럼을 기준으로 그룹화하여 그룹별로 결과를 출력하는 함수를 말한다.
2. 그룹함수는 통계적인 결과ㅑ를 출력하는데 사용된다.
3. 형식
	SELECT 그룹할 컬럼, 그룹함수(대상컬럼)
	FROM 테이블
	GROUP BY 그룹할 컬럼
	HAVING 그룹함수의 결과기준으로 조건처리
4. 그룹함수의 종류(NULL 제외)
	COUNT() : 행의 갯수
	MAX() : 행의 최대값
	MIN() : 행의 최소값
	SUM() : 모든 행의 합
	AVG() : 행의 평균값
	STDDEV() : 표준편차
	VARIANCE() : 분산
*/
-- COUNT(컬럼명) : 해당 컬럼의 데이터 건수를 가져오는데, NULL은 제외 한다.
SELECT COUNT(EMPNO) "사원번호 데이터 갯수", COUNT(COMM) "보너스 갯수"
FROM EMP;
SELECT COUNT(*) "전체 사원정보 건수"
FROM EMP;
-- EX) MGR(관리자)의 데이터 건수와 SAL의 데이터 건수를 확인하세요.
SELECT COUNT(MGR) "관리자건수", COUNT(SAL) "급여건수"
FROM EMP;

SELECT DEPTNO, EMPNO
FROM EMP
ORDER BY DEPTNO, EMPNO;
-- 부서별로 통계치를 처리하고자 할 때, 그룹함수의 형식으로 사용된다.
-- 부서별로 사원번호의 갯수를 가져오고자 할 때, 아래 형식으로 처리
/*
SELECT 그룹 할 컬럼, 그룹함수(대상컬럼)
FROM 테이블명
GROUP BY 그룹할컬럼
*/
SELECT DEPTNO "부서번호", COUNT(EMPNO) "사원번호"
FROM EMP
GROUP BY DEPTNO
ORDER BY DEPTNO;

SELECT JOB, SAL
FROM EMP
ORDER BY JOB, SAL;

SELECT JOB "칙책", COUNT(SAL) "급여"
FROM EMP
GROUP BY JOB
ORDER BY JOB;

SELECT JOB, COUNT(*) "사원정보건수"
FROM EMP
GROUP BY JOB
ORDER BY JOB;

SELECT JOB, COUNT(*) "직책별건수", MAX(SAL) "급여최대치", MIN(SAL) "급여최소", AVG(SAL) "급여평균"
FROM EMP
GROUP BY JOB
ORDER BY JOB;
SELECT JOB, SAL
FROM EMP
ORDER BY JOB, SAL;

SELECT DEPTNO, SAL
FROM EMP
ORDER BY DEPTNO, SAL;

SELECT DEPTNO, COUNT(*) "부서별건수", MAX(SAL) "급여최대치", MIN(SAL) "급여최소", AVG(SAL) "급여평균"
FROM EMP
GROUP BY DEPTNO
ORDER BY DEPTNO;

SELECT ENAME, HIREDATE
FROM EMP
ORDER BY HIREDATE;
SELECT MIN(HIREDATE) "가장먼저입사일", MAX(HIREDATE) "최후입사일"
FROM EMP;
SELECT DEPTNO, MIN(HIREDATE) "가장먼저입사일", MAX(HIREDATE) "최후입사일"
FROM EMP
GROUP BY DEPTNO
ORDER BY DEPTNO;

SELECT JOB, MIN(HIREDATE) "가장먼저입사일", MAX(HIREDATE) "최후입사일"
FROM EMP
GROUP BY JOB
ORDER BY JOB;

CREATE TABLE orders (
    order_id INT PRIMARY KEY,
    wizard_name VARCHAR2(50),
    order_date DATE,
    order_amount INT
);

INSERT INTO orders (order_id, wizard_name, order_date, order_amount) 
VALUES (1, 'Harry Potter', TO_DATE('2025-04-01', 'YYYY-MM-DD'), 100);
INSERT INTO orders (order_id, wizard_name, order_date, order_amount) 
VALUES (2, 'Harry Potter', TO_DATE('2025-04-03', 'YYYY-MM-DD'), 150);
INSERT INTO orders (order_id, wizard_name, order_date, order_amount) 
VALUES (3, 'Hermione Granger', TO_DATE('2025-04-01', 'YYYY-MM-DD'), 200);
INSERT INTO orders (order_id, wizard_name, order_date, order_amount) 
VALUES (4, 'Hermione Granger', TO_DATE('2025-04-02', 'YYYY-MM-DD'), 180);
INSERT INTO orders (order_id, wizard_name, order_date, order_amount) 
VALUES (5, 'Ron Weasley', TO_DATE('2025-04-02', 'YYYY-MM-DD'), 120);
INSERT INTO orders (order_id, wizard_name, order_date, order_amount) 
VALUES (6, 'Ron Weasley', TO_DATE('2025-04-03', 'YYYY-MM-DD'), 130);
INSERT INTO orders (order_id, wizard_name, order_date, order_amount) 
VALUES (7, 'Draco Malfoy', TO_DATE('2025-04-01', 'YYYY-MM-DD'), 250);
INSERT INTO orders (order_id, wizard_name, order_date, order_amount) 
VALUES (8, 'Draco Malfoy', TO_DATE('2025-04-03', 'YYYY-MM-DD'), 220);
INSERT INTO orders (order_id, wizard_name, order_date, order_amount) 
VALUES (9, 'Ginny Weasley', TO_DATE('2025-04-01', 'YYYY-MM-DD'), 150);
INSERT INTO orders (order_id, wizard_name, order_date, order_amount) 
VALUES (10, 'Ginny Weasley', TO_DATE('2025-04-04', 'YYYY-MM-DD'), 130);
COMMIT;
SELECT * FROM orders;

SELECT WIZARD_NAME, ORDER_DATE, ORDER_AMOUNT
FROM ORDERS;
SELECT WIZARD_NAME, MIN(ORDER_DATE) "최초 주문 날짜", MAX(ORDER_DATE) "최후 주문 날짜"
FROM ORDERS
GROUP BY WIZARD_NAME
ORDER BY WIZARD_NAME;
SELECT WIZARD_NAME, COUNT(order_amount) "주문건수", AVG(order_amount) "평균 주문량"
FROM ORDERS
GROUP BY WIZARD_NAME
ORDER BY WIZARD_NAME;
SELECT WIZARD_NAME, COUNT(order_amount) "주문건수", AVG(order_amount) "평균 주문량"
FROM ORDERS
WHERE WIZARD_NAME LIKE '%Ron%'  -- 일반 WHERE 조건절의 위치
GROUP BY WIZARD_NAME;
-- EX) 그룹 함수가 적용된 조건처리 GROUP BY 밑에 HAVING으로 선언하여 처리
--	   주문량의 평균이 190이상인 경우
SELECT WIZARD_NAME, COUNT(order_amount) "주문건수", AVG(order_amount) "평균 주문량"
FROM ORDERS
GROUP BY WIZARD_NAME
HAVING AVG(ORDER_AMOUNT)>=190;

-- SUM() G합산을 처리
-- EX) 직책별 급여의 합산을 출력하되 합산 급액이 8000이상인 것을 직책과 합산금액
SELECT JOB "직책", SUM(SAL) "급여의 합산"
FROM EMP
GROUP BY JOB
HAVING SUM(SAL)>=8000;

SELECT JOB, COUNT(SAL), MIN(SAL), MAX(SAL), SUM(SAL)
FROM EMP
GROUP BY JOB
HAVING SUM(SAL)>=8000;

CREATE TABLE students (
    student_id INT,
    student_name VARCHAR2(50),
    subject VARCHAR2(50),
    score INT
);
INSERT INTO students (student_id, student_name, subject, score) VALUES (1, 'Harry', 'Potions', 90);
INSERT INTO students (student_id, student_name, subject, score) VALUES (2, 'Hermione', 'Potions', 85);
INSERT INTO students (student_id, student_name, subject, score) VALUES (3, 'Ron', 'Potions', 80);
INSERT INTO students (student_id, student_name, subject, score) VALUES (1, 'Harry', 'Herbology', 75);
INSERT INTO students (student_id, student_name, subject, score) VALUES (2, 'Hermione', 'Herbology', 95);
INSERT INTO students (student_id, student_name, subject, score) VALUES (3, 'Ron', 'Herbology', 60);
SELECT * FROM STUDENTS;
SELECT subject "과목", AVG(score) "평균 점수"
FROM students
GROUP BY subject;
SELECT subject "과목", MAX(score) "최고 점수"
FROM students
GROUP BY subject;
SELECT subject "과목", MIN(score) "최저 점수"
FROM students
GROUP BY subject
HAVING MIN(score)<80;

