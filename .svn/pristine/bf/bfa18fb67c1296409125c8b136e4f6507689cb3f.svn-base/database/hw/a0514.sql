/*
1. **사원의 급여가 5000 이상인 사람들을 찾아서 그들의 부서와 함께 출력하세요.**
   *“영화관에서 일이 끝나고, 사장님은 급여가 5000 이상인 직원들에게 특별 보너스를 주기로 했습니다. 직원들의 이름과 부서명을 함께 출력하세요!”*

SELECT E.ENAME "사원명", D.DNAME "부서명"
	FROM EMP E, DEPT D
	WHERE E.DEPTNO = D.DEPTNO AND E.SAL >=5000;

2. **영화 장르가 ‘SF’인 영화와 그 영화를 본 고객들의 이름을 출력하세요.**
   *“영화관에서 SF 영화를 좋아하는 사람들이 모여 파티를 열었습니다. 그 영화를 본 고객들의 이름과 함께, 그 영화의 장르를 출력하세요!”*

SELECT GENRE "영화장르", TITLE "영화타이틀", NAME "고객이름"
	FROM MOVIE M, CUSTOMER C
	WHERE M.MOVIE_ID = C.MOVIE_ID AND M.GENRE = 'SF';

3. **각 부서에서 가장 높은 급여를 받는 사원의 이름과 급여를 출력하세요.**
   *“부서별로 제일 높은 급여를 받는 사원을 찾는 데 필요한 SQL을 작성해보세요. 이 사람들은 부서에서 인정받는 최고의 급여를 받는 직원들이죠!”*

SELECT ENAME "사원명", SAL "최고 급여", DEPTNO "부서 번호" FROM EMP
WHERE (DEPTNO, SAL) IN(
	SELECT DEPTNO, MAX(SAL) "최고 급여"
	FROM EMP
	GROUP BY DEPTNO
);

4. **최고급여를 받는 사원의 이름과 급여를 출력하세요.**
   *“회사에서 최고급여를 받는 사람은 누구일까요? 그 사람의 이름과 급여를 출력해보세요.”*

SELECT ENAME, SAL FROM EMP 
WHERE SAL = (SELECT MAX(SAL) FROM EMP);

5. **모든 직원과 그들의 관리자 이름을 출력하세요. (SELF JOIN 사용)**
   *“사원과 상사들 간의 관계를 보여주는 리스트를 만들어 보세요. 이 정보를 보고 관리자와 사원 간의 연결고리를 파악할 수 있습니다!”*

SELECT E.ENAME "사원이름", E.MGR "관리자의 사원번호", M.ENAME "관리자의 이름"
FROM EMP E, EMP M
WHERE E.MGR = M.EMPNO; 

6. **고객들이 본 영화 중, '액션' 장르 영화를 본 사람들의 이름과 영화 제목을 출력하세요.**
   *“액션 영화를 좋아하는 고객들을 찾아보세요. 그들이 본 액션 영화의 제목과 고객 이름을 출력하세요!”*

SELECT GENRE "영화장르", TITLE "영화타이틀", NAME "고객이름"
	FROM MOVIE M, CUSTOMER C
	WHERE M.MOVIE_ID = C.MOVIE_ID AND M.GENRE = '액션';

7. **영화 제목을 기준으로 고객 이름을 찾아 출력하세요. (NULL 값 처리 포함)**
   *“영화관에서는 다양한 장르의 영화를 제공합니다. 고객이 본 영화 제목을 기준으로 고객 이름을 출력하려면 어떻게 해야 할까요? NULL 값을 고려하여 작성해보세요!”*

SELECT C.*, M.TITLE
FROM CUSTOMER C
RIGHT OUTER JOIN MOVIE M
ON C.MOVIE_ID = M.MOVIE_ID;

*/
