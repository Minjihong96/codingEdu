/*
5. 데이터베이스에서 부서번호로 직원들의 이름을 조회하여 리스트로 반환하는 메서드를 작성하고, 그 결과를 출력해보세요.
*/
SELECT * FROM EMP;
SELECT ENAME FROM EMP WHERE DEPTNO = 10;
/*
public List<String> getEnameDeptno(int deptno){
	List<String> ename = new ArrayList<String>();
	String sql = "SELECT ENAME FROM EMP WHERE DEPTNO = ?";
	
	return ename;
}
*/
/*
4. PreparedStatement를 사용하여 데이터베이스에서 사원의 급여를 조회하고, 그 급여를 통해 사원의 직급을 구하는 과정을 실제 코드로 나타내보세요.
*/
SELECT MGR FROM EMP WHERE SAL = 1250;
/*
public List<Integer> getMgrSal(double sal){
	List<Integer> mgr = new ArrayList<Integer>();
	String sql = "SELECT MGR FROM EMP WHERE SAL = ?";
	
	return mgr;
}
*/