/*
### 1. **"문자열 급여 문제"**

회계팀의 김과장은 부서 직원들의 급여 데이터를 Excel로 정리하려고 합니다. 그런데 급여는 모두 문자열 '3,500'과 같은 형식으로 입력되어 있어 계산이 불가능했습니다.
**문제:**
이 급여들을 숫자형으로 변환하여 3500 이상인 직원만 조회하는 SQL 문을 작성하세요.

---
 
*/
SELECT ENAME, SAL
FROM EMP
WHERE SAL >= TO_NUMBER('3000');	   
/*
### 2. **"입사일 로그 시스템"**

개발팀은 사원들의 입사일 데이터를 로그에 남기기 위해 `YYYY-MM-DD HH24:MI:SS` 형식으로 출력하려고 합니다.
**문제:**
사원번호, 사원명, 입사일을 해당 형식으로 출력하는 SQL 문을 작성하세요.

--- 
*/
SELECT EMPNO, ENAME, TO_CHAR(HIREDATE, 'YYYY-MM-DD HH24:MI:SS') "입사일"
FROM EMP;
/*
### 3. **"자동 회원번호 생성기"**

스타트업 '다함께회사'는 회원가입 시 회원번호를 자동으로 1001번부터 부여하고자 합니다.
**문제:**
이 요구사항을 반영한 `SEQUENCE` 생성 구문을 작성하세요.

---
*/
CREATE SEQUENCE TOGETHERCOM
	START WITH 1001;
/*
### 4. **"DAO 처리 실수"**

신입 개발자 민수는 아래와 같이 DAO 메서드를 작성했지만 데이터가 조회되지 않았습니다.

```java
String sql = "SELECT * FROM EMP WHERE ENAME = ? AND JOB = ?";
pstmt.setString(1, sch.getEname());
pstmt.setString(2, sch.getJob());
```
String sql = "SELECT * FROM EMP WHERE ENAME LIKE ? AND JOB LIKE ?;"
pstmt.setString(1, "%" + sch.getEname() + "%");
pstmt.setString(2, "%" + sch.getJob() + "%");

하지만 사용자가 입력한 검색 조건은 `이름에 A가 포함`되고 `직책에 MAN이 포함`된 데이터입니다.
**문제:**
해당 조건에 맞도록 SQL과 `setString` 구문을 수정해 보세요.
*/
SELECT * FROM EMP WHERE ENAME LIKE '%A%' AND JOB LIKE '%MAN%';

/*

### 5. **"다중 행 이름 수집기"**

부장님은 부서번호가 30번인 모든 직원 이름을 리스트로 받아보고 싶어 합니다.
**문제:**
이 요구를 만족시키기 위한 Java DAO 메서드를 작성할 때, 반환 타입과 SQL 구문을 기술하세요.

public List<String> getEnamesByDeptno(int deptno){
	List<String> enameList = new ArrayList<String>();
	String sql="SELECT ENAME FROM EMP10 WHERE DEPTNO = ?";
	
	
	return enameList;
}
*/
SELECT ENAME FROM EMP10 WHERE DEPTNO =30;