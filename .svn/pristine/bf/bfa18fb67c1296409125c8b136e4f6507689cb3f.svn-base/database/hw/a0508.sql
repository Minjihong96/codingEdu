SELECT * FROM EMP;
/*
4. **“보너스도 사랑받고 싶다!”**
   보너스가 NULL이면 0으로 바꿔서 출력해주는 모든 사원 조회 기능을 만들어보세요. 그리고 전체 인원도 함께 출력하세요.    
*/
SELECT ENAME, NVL(COMM,0) "보너스"
FROM EMP;
